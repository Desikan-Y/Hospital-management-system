import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import { User, Doctor, Appointment, Specialization, SystemStats } from "./src/types";

const app = express();
const PORT = 3000;
const DB_PATH = path.join(process.cwd(), "data", "db.json");

// Ensure data directory exists
if (!fs.existsSync(path.join(process.cwd(), "data"))) {
  fs.mkdirSync(path.join(process.cwd(), "data"));
}

// Helpers for Hashing & Tokens
function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

function generateToken(payload: { id: string; role: string; email: string }): string {
  return Buffer.from(JSON.stringify(payload)).toString("base64");
}

function verifyToken(token: string): { id: string; role: string; email: string } | null {
  try {
    const raw = Buffer.from(token, "base64").toString("utf-8");
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

// Low-cost Database Structure
interface DatabaseSchema {
  users: Array<User & { passwordHash: string }>;
  doctors: Array<Doctor & { passwordHash: string }>;
  appointments: Appointment[];
}

const DEFAULT_DOCTORS: Array<Doctor & { passwordHash: string }> = [
  {
    id: "doc-1",
    name: "Dr. Richard Jenkins",
    email: "richard@health.com",
    role: "doctor",
    specialization: "Cardiologist",
    qualification: "MD - Cardiology, Johns Hopkins University",
    experience: 12,
    fees: 150,
    about: "Dr. Jenkins is a senior cardiologist with a passion for preventive medicine and structural checkups. He spends extra care explaining cardiovascular wellness plans to his patients.",
    availability: ["Monday", "Wednesday", "Friday"],
    timings: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"],
    approved: true,
    image: "cardiologist",
    passwordHash: hashPassword("doctor123")
  },
  {
    id: "doc-2",
    name: "Dr. Emily Martinez",
    email: "emily@health.com",
    role: "doctor",
    specialization: "Dentist",
    qualification: "DDS - Pediatric Dentistry, Harvard Dental School",
    experience: 8,
    fees: 90,
    about: "Dr. Martinez is dedicated to comfortable dental treatments and gentle oral wellness. She is recognized for pediatric dental care and digital orthodontics guidance.",
    availability: ["Monday", "Tuesday", "Thursday"],
    timings: ["10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM", "04:00 PM"],
    approved: true,
    image: "dentist",
    passwordHash: hashPassword("doctor123")
  },
  {
    id: "doc-3",
    name: "Dr. James Carter",
    email: "carter@health.com",
    role: "doctor",
    specialization: "Neurologist",
    qualification: "PhD - Neurology, Stanford University",
    experience: 15,
    fees: 200,
    about: "Dr. Carter manages complex neurological cases including sleep issues, focus wellness, neuromuscular treatment, and persistent migraine control strategies.",
    availability: ["Wednesday", "Thursday", "Friday"],
    timings: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "04:00 PM"],
    approved: true,
    image: "neurologist",
    passwordHash: hashPassword("doctor123")
  },
  {
    id: "doc-4",
    name: "Dr. Sarah Jenkins",
    email: "sarah@health.com",
    role: "doctor",
    specialization: "Pediatrician",
    qualification: "MD - Pediatrics, University of Chicago",
    experience: 10,
    fees: 110,
    about: "Dr. Sarah is an expert in child growth indices, immune health, nutrition guides, and pediatric immunization protocols. Parents love her joyful approach to clinic visits.",
    availability: ["Tuesday", "Wednesday", "Friday"],
    timings: ["08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM"],
    approved: true,
    image: "pediatrician",
    passwordHash: hashPassword("doctor123")
  },
  {
    id: "doc-5",
    name: "Dr. Michael Vance",
    email: "vance@health.com",
    role: "doctor",
    specialization: "Orthopedic",
    qualification: "MS - Orthopedic Medicine, Mayo Clinic",
    experience: 14,
    fees: 140,
    about: "Dr. Michael specializes in joint restoration, posture management, athletic injuries, and spinal structure alignment therapies for active individuals.",
    availability: ["Monday", "Tuesday", "Thursday"],
    timings: ["09:00 AM", "10:00 AM", "01:00 PM", "02:00 PM", "03:00 PM"],
    approved: true,
    image: "orthopedic",
    passwordHash: hashPassword("doctor123")
  },
  {
    id: "doc-6",
    name: "Dr. Ava Thomas",
    email: "ava@health.com",
    role: "doctor",
    specialization: "Dermatologist",
    qualification: "MD - Dermatology, Yale School of Medicine",
    experience: 7,
    fees: 120,
    about: "Dr. Ava uses state-of-the-art dermatological assessments to balance skin barrier concerns, allergies, aesthetic medicine, and systemic auto-immune derm checkups.",
    availability: ["Tuesday", "Wednesday", "Thursday"],
    timings: ["10:00 AM", "11:00 AM", "01:00 PM", "03:00 PM", "04:00 PM"],
    approved: true,
    image: "dermatologist",
    passwordHash: hashPassword("doctor123")
  },
  {
    id: "doc-7",
    name: "Dr. David Miller",
    email: "david@health.com",
    role: "doctor",
    specialization: "General Physician",
    qualification: "MBBS, Boston University Medicine",
    experience: 9,
    fees: 80,
    about: "Dr. Miller offers comprehensive screening, diabetic counseling, blood pressure regulation, and initial triage diagnosis for families and adult health management.",
    availability: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    timings: ["09:00 AM", "10:00 AM", "11:00 AM", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM"],
    approved: true,
    image: "general physician",
    passwordHash: hashPassword("doctor123")
  }
];

const DEFAULT_USERS: Array<User & { passwordHash: string }> = [
  {
    id: "admin-1",
    name: "Hospital Admin",
    email: "admin@health.com",
    role: "admin",
    passwordHash: hashPassword("admin123")
  },
  {
    id: "pat-1",
    name: "John Doe",
    email: "john@demo.com",
    role: "patient",
    phone: "123-456-7890",
    gender: "Male",
    age: 28,
    passwordHash: hashPassword("patient123")
  }
];

function loadDatabase(): DatabaseSchema {
  if (!fs.existsSync(DB_PATH)) {
    const initialDB: DatabaseSchema = {
      users: DEFAULT_USERS,
      doctors: DEFAULT_DOCTORS,
      appointments: [
        {
          id: "appt-1",
          patientId: "pat-1",
          patientName: "John Doe",
          patientAge: 28,
          patientPhone: "123-456-7890",
          patientEmail: "john@demo.com",
          doctorId: "doc-1",
          doctorName: "Dr. Richard Jenkins",
          doctorSpecialization: "Cardiologist",
          date: new Date(Date.now() + 86400000 * 2).toISOString().split("T")[0], // 2 days in future
          timeSlot: "11:00 AM",
          fee: 150,
          paymentStatus: "Paid",
          transactionId: "TXN_77488390",
          status: "Upcoming"
        },
        {
          id: "appt-2",
          patientId: "pat-1",
          patientName: "John Doe",
          patientAge: 28,
          patientPhone: "123-456-7890",
          patientEmail: "john@demo.com",
          doctorId: "doc-2",
          doctorName: "Dr. Emily Martinez",
          doctorSpecialization: "Dentist",
          date: new Date(Date.now() - 86400000).toISOString().split("T")[0], // 1 day in past
          timeSlot: "02:00 PM",
          fee: 90,
          paymentStatus: "Paid",
          transactionId: "TXN_11204958",
          status: "Completed"
        }
      ]
    };
    saveDatabase(initialDB);
    return initialDB;
  }

  try {
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Error reading database, resetting...", error);
    return { users: DEFAULT_USERS, doctors: DEFAULT_DOCTORS, appointments: [] };
  }
}

function saveDatabase(db: DatabaseSchema) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
}

// Express Core Middleware
app.use(express.json());

// Auth Extract Middleware
function authMiddleware(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid authorization token" });
  }

  const token = authHeader.split(" ")[1];
  const authenticated = verifyToken(token);
  if (!authenticated) {
    return res.status(401).json({ error: "Token signature expired or tampered" });
  }

  req.user = authenticated;
  next();
}

// ---------------- AUTH ROUTES ----------------

// Register Patient
app.post("/api/auth/register", (req, res) => {
  const { name, email, password, phone, gender, age } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Required fields: name, email, password" });
  }

  const db = loadDatabase();
  const emailLower = email.toLowerCase().trim();

  const userExists = db.users.some(u => u.email.toLowerCase() === emailLower) || 
                     db.doctors.some(d => d.email.toLowerCase() === emailLower);

  if (userExists) {
    return res.status(400).json({ error: "Email already registered in system" });
  }

  const newPatient: User & { passwordHash: string } = {
    id: `pat-${Date.now()}`,
    name: name.trim(),
    email: emailLower,
    role: "patient",
    phone: phone || "",
    gender: gender || "Not Specified",
    age: Number(age) || 30,
    passwordHash: hashPassword(password)
  };

  db.users.push(newPatient);
  saveDatabase(db);

  const token = generateToken({ id: newPatient.id, role: newPatient.role, email: newPatient.email });
  const { passwordHash, ...userClean } = newPatient;

  res.status(201).json({ user: userClean, token });
});

// Universal Login (Patients, Doctors, Admin)
app.post("/api/auth/login", (req, res) => {
  const { email, password, role } = req.body;
  if (!email || !password || !role) {
    return res.status(400).json({ error: "Please provide email, password, and selection role" });
  }

  const db = loadDatabase();
  const emailLower = email.toLowerCase().trim();
  const passHash = hashPassword(password);

  if (role === "patient" || role === "admin") {
    const user = db.users.find(u => u.email.toLowerCase() === emailLower && u.role === role);
    if (!user || user.passwordHash !== passHash) {
      return res.status(401).json({ error: "Invalid credentials or unauthorized role" });
    }

    const token = generateToken({ id: user.id, role: user.role, email: user.email });
    const { passwordHash, ...cleanUser } = user;
    return res.json({ user: cleanUser, token });
  } else if (role === "doctor") {
    const doc = db.doctors.find(d => d.email.toLowerCase() === emailLower);
    if (!doc || doc.passwordHash !== passHash) {
      return res.status(401).json({ error: "Invalid medical credentials" });
    }

    if (!doc.approved) {
      return res.status(403).json({ error: "Your doctor registration is pending administrator approval." });
    }

    const token = generateToken({ id: doc.id, role: doc.role, email: doc.email });
    const { passwordHash, ...cleanDoc } = doc;
    return res.json({ user: cleanDoc, token });
  }

  res.status(400).json({ error: "Unsupported system role specified" });
});

// Retrieve Self Details
app.get("/api/auth/me", authMiddleware, (req: any, res) => {
  const db = loadDatabase();
  const { id, role } = req.user;

  if (role === "admin" || role === "patient") {
    const user = db.users.find(u => u.id === id);
    if (!user) return res.status(404).json({ error: "User session expired" });
    const { passwordHash, ...clean } = user;
    return res.json({ user: clean });
  } else if (role === "doctor") {
    const doc = db.doctors.find(d => d.id === id);
    if (!doc) return res.status(404).json({ error: "Doctor registry not found" });
    const { passwordHash, ...clean } = doc;
    return res.json({ user: clean });
  }

  res.status(400).json({ error: "Invalid role identifier" });
});

// Update self profile (Patients update age/phone/name, Doctors update experience/fees/about/timings/availability)
app.put("/api/auth/profile", authMiddleware, (req: any, res) => {
  const db = loadDatabase();
  const { id, role } = req.user;

  if (role === "patient") {
    const idx = db.users.findIndex(u => u.id === id);
    if (idx === -1) return res.status(404).json({ error: "Patient record not found" });

    const { name, phone, gender, age } = req.body;
    if (name) db.users[idx].name = name;
    if (phone !== undefined) db.users[idx].phone = phone;
    if (gender !== undefined) db.users[idx].gender = gender;
    if (age !== undefined) db.users[idx].age = Number(age);

    saveDatabase(db);
    const { passwordHash, ...clean } = db.users[idx];
    return res.json({ message: "Profile updated safely", user: clean });
  } else if (role === "doctor") {
    const idx = db.doctors.findIndex(d => d.id === id);
    if (idx === -1) return res.status(404).json({ error: "Doctor profile record not found" });

    const { experience, fees, about, availability, timings, name } = req.body;
    if (name) db.doctors[idx].name = name;
    if (experience !== undefined) db.doctors[idx].experience = Number(experience);
    if (fees !== undefined) db.doctors[idx].fees = Number(fees);
    if (about !== undefined) db.doctors[idx].about = about;
    if (availability !== undefined) db.doctors[idx].availability = availability;
    if (timings !== undefined) db.doctors[idx].timings = timings;

    saveDatabase(db);
    const { passwordHash, ...clean } = db.doctors[idx];
    return res.json({ message: "Medical profile updated safely", user: clean });
  }

  res.status(400).json({ error: "Admins cannot update details through this profile gateway" });
});


// ---------------- DOCTORS ROUTES ----------------

// Filterable Listing
app.get("/api/doctors", (req, res) => {
  const db = loadDatabase();
  const { specialization, search } = req.query;

  let list = db.doctors.map(({ passwordHash, ...clean }) => clean);

  if (specialization) {
    list = list.filter(d => d.specialization.toLowerCase() === String(specialization).toLowerCase());
  }

  if (search) {
    const q = String(search).toLowerCase();
    list = list.filter(d => 
      d.name.toLowerCase().includes(q) || 
      d.specialization.toLowerCase().includes(q) ||
      d.qualification.toLowerCase().includes(q)
    );
  }

  res.json(list);
});

// Single Doctor Detailed Lookup
app.get("/api/doctors/:id", (req, res) => {
  const db = loadDatabase();
  const doc = db.doctors.find(d => d.id === req.params.id);
  if (!doc) {
    return res.status(404).json({ error: "Doctor metadata not found in system" });
  }
  const { passwordHash, ...clean } = doc;
  res.json(clean);
});

// Admin Add Doctor
app.post("/api/doctors", authMiddleware, (req: any, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Only global administrators can manually register doctors" });
  }

  const { name, email, password, specialization, qualification, experience, fees, about, availability, timings } = req.body;
  if (!name || !email || !password || !specialization || !fees) {
    return res.status(400).json({ error: "Please input high priority doctor registry parameters" });
  }

  const db = loadDatabase();
  const emailLower = email.toLowerCase().trim();

  const exists = db.doctors.some(d => d.email.toLowerCase() === emailLower) ||
                 db.users.some(u => u.email.toLowerCase() === emailLower);

  if (exists) {
    return res.status(400).json({ error: "Email address is already reserved inside system" });
  }

  const newDoc: Doctor & { passwordHash: string } = {
    id: `doc-${Date.now()}`,
    name,
    email: emailLower,
    role: "doctor",
    specialization: specialization as Specialization,
    qualification: qualification || "General Practitioner",
    experience: Number(experience) || 3,
    fees: Number(fees),
    about: about || "Specialized clinic consulting physician.",
    availability: availability || ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    timings: timings || ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"],
    approved: true, // Admin-created is auto-approved
    image: specialization.toLowerCase().replace(" ", "_"),
    passwordHash: hashPassword(password)
  };

  db.doctors.push(newDoc);
  saveDatabase(db);

  const { passwordHash, ...clean } = newDoc;
  res.status(201).json({ message: "Doctor registered and verified successfully!", doctor: clean });
});

// Admin Approve Doctor Register (for self-registered or pending doctors)
app.put("/api/doctors/:id/approve", authMiddleware, (req: any, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Only admins can complete approval workflows" });
  }

  const db = loadDatabase();
  const idx = db.doctors.findIndex(d => d.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Doctor registry not found" });

  db.doctors[idx].approved = true;
  saveDatabase(db);
  res.json({ message: "Doctor program successfully approved", doctor: db.doctors[idx] });
});

// Admin Toggle Doctor Status/Details OR Direct Edit
app.put("/api/doctors/:id", authMiddleware, (req: any, res) => {
  const db = loadDatabase();
  const idx = db.doctors.findIndex(d => d.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Doctor profile not in database" });

  // Doctor modifies themselves, or Admin modifies them
  if (req.user.role !== "admin" && req.user.id !== req.params.id) {
    return res.status(403).json({ error: "Access Denied: cannot update this clinic professional" });
  }

  const fields = req.body;
  if (fields.name) db.doctors[idx].name = fields.name;
  if (fields.specialization) db.doctors[idx].specialization = fields.specialization;
  if (fields.qualification) db.doctors[idx].qualification = fields.qualification;
  if (fields.experience !== undefined) db.doctors[idx].experience = Number(fields.experience);
  if (fields.fees !== undefined) db.doctors[idx].fees = Number(fields.fees);
  if (fields.about) db.doctors[idx].about = fields.about;
  if (fields.availability) db.doctors[idx].availability = fields.availability;
  if (fields.timings) db.doctors[idx].timings = fields.timings;
  if (fields.approved !== undefined && req.user.role === "admin") db.doctors[idx].approved = fields.approved;

  saveDatabase(db);
  const { passwordHash, ...clean } = db.doctors[idx];
  res.json({ message: "Medical registry updated gracefully", doctor: clean });
});

// Admin Remove Doctor
app.delete("/api/doctors/:id", authMiddleware, (req: any, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Only administrators are cleared for database deletion" });
  }

  const db = loadDatabase();
  const countBefore = db.doctors.length;
  db.doctors = db.doctors.filter(d => d.id !== req.params.id);

  if (db.doctors.length === countBefore) {
    return res.status(404).json({ error: "Doctor not found" });
  }

  saveDatabase(db);
  res.json({ message: "Doctor removed from hospital directories" });
});


// ---------------- APPOINTMENT ROUTES ----------------

// Fetch Appointments (context sensitive: patient gets their own, doctor gets theirs, admin gets all)
app.get("/api/appointments", authMiddleware, (req: any, res) => {
  const db = loadDatabase();
  const { id, role } = req.user;

  let filtered = db.appointments;

  if (role === "patient") {
    filtered = db.appointments.filter(a => a.patientId === id);
  } else if (role === "doctor") {
    filtered = db.appointments.filter(a => a.doctorId === id);
  } // admin views all

  // Sort by date and then timeSlot
  filtered.sort((a, b) => {
    const dComp = a.date.localeCompare(b.date);
    if (dComp !== 0) return dComp;
    return a.timeSlot.localeCompare(b.timeSlot);
  });

  res.json(filtered);
});

// Book Appointment (Patient role)
app.post("/api/appointments", authMiddleware, (req: any, res) => {
  if (req.user.role !== "patient") {
    return res.status(403).json({ error: "Only registered patients can request active consultation bookings" });
  }

  const { doctorId, date, timeSlot } = req.body;
  if (!doctorId || !date || !timeSlot) {
    return res.status(400).json({ error: "Please input doctorId, date, and timeSlot parameters" });
  }

  const db = loadDatabase();
  
  // Find Doctor
  const doc = db.doctors.find(d => d.id === doctorId);
  if (!doc) return res.status(404).json({ error: "Doctor lookup failed" });

  // Find Patient details
  const pat = db.users.find(u => u.id === req.user.id);
  if (!pat) return res.status(404).json({ error: "Your patient database profile cannot be matched" });

  // Double booking validation: Check if slot already reserved
  const isBooked = db.appointments.some(
    a => a.doctorId === doctorId && a.date === date && a.timeSlot === timeSlot && a.status !== "Cancelled"
  );

  if (isBooked) {
    return res.status(422).json({ error: "This doctor slot of time is already booked by another clinic visit" });
  }

  const newAppt: Appointment = {
    id: `appt-${Date.now()}`,
    patientId: pat.id,
    patientName: pat.name,
    patientAge: pat.age || 30,
    patientPhone: pat.phone || "Not provided",
    patientEmail: pat.email,
    doctorId: doc.id,
    doctorName: doc.name,
    doctorSpecialization: doc.specialization,
    date,
    timeSlot,
    fee: doc.fees,
    paymentStatus: "Pending",
    transactionId: null,
    status: "Upcoming"
  };

  db.appointments.push(newAppt);
  saveDatabase(db);

  res.status(201).json({ message: "Appointment requested! Please complete your checkout processing", appointment: newAppt });
});

// Simulated Checkout Payment Route
app.put("/api/appointments/:id/pay", authMiddleware, (req: any, res) => {
  if (req.user.role !== "patient") {
    return res.status(403).json({ error: "Only patients are permitted to configure payments" });
  }

  const db = loadDatabase();
  const idx = db.appointments.findIndex(a => a.id === req.params.id && a.patientId === req.user.id);

  if (idx === -1) {
    return res.status(404).json({ error: "Eligible appointment not matched to your account status" });
  }

  if (db.appointments[idx].status === "Cancelled") {
    return res.status(400).json({ error: "Payment cannot be processed for cancelled appointments" });
  }

  // Set paid status and mock a transaction ID
  db.appointments[idx].paymentStatus = "Paid";
  db.appointments[idx].transactionId = `TXN_${Math.floor(10000000 + Math.random() * 90000000)}`;
  
  saveDatabase(db);
  res.json({ message: "Fee payment was captured securely by payment gateway simulation", appointment: db.appointments[idx] });
});

// Cancel Appointment Status (Allowed by Patient, Doctor or Admin)
app.put("/api/appointments/:id/cancel", authMiddleware, (req: any, res) => {
  const db = loadDatabase();
  const idx = db.appointments.findIndex(a => a.id === req.params.id);

  if (idx === -1) {
    return res.status(404).json({ error: "Consultation appointment key not found" });
  }

  const appt = db.appointments[idx];
  const { id, role } = req.user;

  // Authorization check
  if (role === "patient" && appt.patientId !== id) {
    return res.status(403).json({ error: "Access Denied: Cannot cancel another patient's slot" });
  }
  if (role === "doctor" && appt.doctorId !== id) {
    return res.status(403).json({ error: "Access Denied: This appointment does not map to your list" });
  }

  db.appointments[idx].status = "Cancelled";
  saveDatabase(db);

  res.json({ message: "Consultation appointment reservation successfully cancelled", appointment: db.appointments[idx] });
});

// Complete Appointment Action (Doctor only)
app.put("/api/appointments/:id/complete", authMiddleware, (req: any, res) => {
  if (req.user.role !== "doctor") {
    return res.status(403).json({ error: "Only medical doctors can sign off appointment completeness" });
  }

  const db = loadDatabase();
  const idx = db.appointments.findIndex(a => a.id === req.params.id && a.doctorId === req.user.id);

  if (idx === -1) {
    return res.status(404).json({ error: "Appointment mapping error" });
  }

  db.appointments[idx].status = "Completed";
  saveDatabase(db);

  res.json({ message: "Appointment state catalogued as Completed successfully", appointment: db.appointments[idx] });
});


// ---------------- ADMIN API STATS & SEARCH ----------------

// Statistics Dashboard
app.get("/api/admin/stats", authMiddleware, (req: any, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Global system performance insights are restricted to admin operations" });
  }

  const db = loadDatabase();

  const totalDoctors = db.doctors.length;
  // Unique patient IDs from appointments or user collection
  const totalPatients = db.users.filter(u => u.role === "patient").length;
  const totalAppointments = db.appointments.length;

  const totalRevenue = db.appointments
    .filter(a => a.paymentStatus === "Paid" && a.status !== "Cancelled")
    .reduce((sum, a) => sum + a.fee, 0);

  const stats: SystemStats = {
    totalDoctors,
    totalPatients,
    totalAppointments,
    totalRevenue
  };

  res.json(stats);
});

// Listing of Patients
app.get("/api/admin/patients", authMiddleware, (req: any, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ error: "Protected patient identity directories are admin locked" });
  }

  const db = loadDatabase();
  const patients = db.users.filter(u => u.role === "patient").map(({ passwordHash, ...clean }) => clean);

  res.json(patients);
});


// ---------------- VITE MIDDLEWARE & STATIC ASSET PIPELINE ----------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Doctor Booking System is active at http://localhost:${PORT}`);
  });
}

startServer();
