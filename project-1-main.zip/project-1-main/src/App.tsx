import React from 'react';
import { AppProvider, useApp } from './components/AppContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { DoctorsView } from './components/DoctorsView';
import { AboutView } from './components/AboutView';
import { ContactView } from './components/ContactView';
import { LoginView } from './components/LoginView';
import { PatientDashboard } from './components/PatientDashboard';
import { DoctorDashboard } from './components/DoctorDashboard';
import { AdminDashboard } from './components/AdminDashboard';

// Inner component to render the appropriate active page view
const ClinicAppContent: React.FC = () => {
  const { activeView, user, loading } = useApp();

  const renderActiveView = () => {
    switch (activeView) {
      case 'home':
        return <HomeView />;
      case 'doctors':
        return <DoctorsView />;
      case 'about':
        return <AboutView />;
      case 'contact':
        return <ContactView />;
      case 'login':
      case 'register':
        return <LoginView />;
      case 'my-appointments':
        return <PatientDashboard />; // PatientDashboard shows bookings registry
      case 'dashboard':
        if (!user) return <LoginView />;
        if (user.role === 'admin') {
          return <AdminDashboard />;
        } else if (user.role === 'doctor') {
          return <DoctorDashboard />;
        } else {
          return <PatientDashboard />;
        }
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      
      {/* Centralized Header Navbar */}
      <Header />

      {/* Global Clinical State Spinner */}
      {loading && (
        <div className="fixed top-0 left-0 w-full h-[2px] bg-emerald-500 overflow-hidden z-50">
          <div className="h-full bg-emerald-200 animate-pulse w-1/3 rounded" style={{ animationDuration: '0.8s' }} />
        </div>
      )}

      {/* Primary Page Canvas */}
      <main className="flex-1">
        {renderActiveView()}
      </main>

      {/* System Footer */}
      <Footer />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <ClinicAppContent />
    </AppProvider>
  );
}
