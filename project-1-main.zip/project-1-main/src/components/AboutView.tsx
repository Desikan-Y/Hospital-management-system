import React from 'react';
import { Shield, Sparkles, Award, ClipboardCheck, ThumbsUp, HeartHandshake } from 'lucide-react';

export const AboutView: React.FC = () => {
  return (
    <div className="py-12 bg-slate-50 min-h-screen" id="about-page-view">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Breadcrumb Header */}
        <div className="text-center space-y-3 mb-10">
          <span className="text-[11px] font-mono tracking-widest text-[#10b981] uppercase font-bold bg-emerald-50 px-2.5 py-1 rounded-full">
            Clinical Standards
          </span>
          <h1 className="font-sans font-bold text-3xl sm:text-4xl text-slate-900 tracking-tight">
            Comprehensive Digital Health Systems
          </h1>
          <p className="font-sans text-sm text-slate-500 max-w-xl mx-auto">
            Providing modern administrative transparency, immediate clinical answers, and comfortable local booking directories.
          </p>
        </div>

        {/* Our Mission & Vision Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="bg-emerald-50 text-emerald-600 p-2.5 rounded-xl w-fit">
              <Sparkles className="w-5 h-5 text-emerald-500" />
            </div>
            <h3 className="font-sans font-bold text-lg text-slate-900">Our Clinical Mission</h3>
            <p className="font-sans text-xs text-slate-500 leading-relaxed">
              We seek to eliminate clinic bottlenecking by providing comfortable, intuitive slot booking mechanics. We believe that receiving essential primary and specialized care is a human right that should be free of logistical overhead.
            </p>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-100 shadow-xs space-y-4">
            <div className="bg-emerald-50 text-emerald-600 p-2.5 rounded-xl w-fit">
              <Shield className="w-5 h-5 text-emerald-500" />
            </div>
            <h3 className="font-sans font-bold text-lg text-slate-900">Our Strategic Vision</h3>
            <p className="font-sans text-xs text-slate-500 leading-relaxed">
              CareSync envisions a future where digitizing and booking doctor appointments online takes under three clicks. We seek to incorporate medical records, real-time feedback, and secure gateway confirmations for patients worldwide.
            </p>
          </div>

        </div>

        {/* Core Values */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-100 shadow-xs mb-12">
          <h3 className="font-sans font-bold text-base text-slate-900 mb-6 text-center">
            The Healthcare Creed We Live By
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            
            <div className="text-center space-y-2">
              <div className="mx-auto w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Award className="w-5 h-5 text-emerald-500" />
              </div>
              <h4 className="font-sans font-semibold text-xs text-slate-950">Vetted Practitioners</h4>
              <p className="font-sans text-[11px] text-slate-400">
                Every doctor in our roster possesses qualified boards and board-certified credentials.
              </p>
            </div>

            <div className="text-center space-y-2">
              <div className="mx-auto w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <ClipboardCheck className="w-5 h-5 text-emerald-500" />
              </div>
              <h4 className="font-sans font-semibold text-xs text-slate-950">Patient Autonomy</h4>
              <p className="font-sans text-[11px] text-slate-400">
                Manage details, control appointment records, and issue cancellations effortlessly.
              </p>
            </div>

            <div className="text-center space-y-2">
              <div className="mx-auto w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <HeartHandshake className="w-5 h-5 text-emerald-500" />
              </div>
              <h4 className="font-sans font-semibold text-xs text-slate-950">Instant Booking</h4>
              <p className="font-sans text-[11px] text-slate-400">
                No endless queues or paper logs. Secure clinic calendars display slots directly in real-time.
              </p>
            </div>

          </div>
        </div>

        {/* Special Services Callout */}
        <div className="bg-emerald-950 text-slate-100 p-8 sm:p-10 rounded-3xl relative overflow-hidden shadow-md">
          <div className="absolute right-0 bottom-0 opacity-10 transform translate-x-12 translate-y-12">
            <HeartHandshake className="w-64 h-64" />
          </div>
          <div className="relative z-10 max-w-lg space-y-4">
            <h3 className="font-sans font-bold text-xl tracking-tight text-white">
              Over 10,000+ Completed Bookings This Year
            </h3>
            <p className="font-sans text-xs text-emerald-200/80 leading-relaxed">
              By working in close harmony with clinics, pediatric hubs, dental groups, and specialist hospitals, CareSync has optimized clinic wait times by up to 40% globally.
            </p>
            <div className="flex gap-4 pt-1">
              <div className="flex items-center gap-1.5 text-xs text-emerald-300">
                <ThumbsUp className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>99.4% Consultation Satisfaction</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
export default AboutView;
