import React, { useState, useEffect } from 'react';
import { useApp } from './AppContext';
import { 
  ShieldAlert, 
  Users, 
  Calendar, 
  DollarSign, 
  Activity, 
  UserPlus, 
  SlidersHorizontal, 
  CheckCircle, 
  Trash2, 
  X, 
  Menu, 
  UserCircle2, 
  Award, 
  Clock, 
  ShieldCheck 
} from 'lucide-react';
import { Doctor, Appointment, User, Specialization } from '../types';

export const AdminDashboard: React.FC = () => {
  const { 
    user, 
    doctors,
    appointments, 
    cancelAppointment, 
    adminAddDoctor, 
    adminApproveDoctor, 
    adminDeleteDoctor,
    adminGetStats,
    adminGetPatients,
    refreshDoctors,
    refreshAppointments
  } = useApp();

  // Selected administrative drawer panel tab
  const [adminTab, setAdminTab] = useState<'stats' | 'doctors' | 'appointments' | 'patients'>('stats');

  // Stats from backend API
  const [perfStats, setPerfStats] = useState<{
    totalDoctors: number;
    totalPatients: number;
    totalAppointments: number;
    totalRevenue: number;
  } | null>(null);

  // Users from backend API
  const [patientsList, setPatientsList] = useState<User[]>([]);

  // Add doctor form fields
  const [addDocName, setAddDocName] = useState('');
  const [addDocEmail, setAddDocEmail] = useState('');
  const [addDocPassword, setAddDocPassword] = useState('');
  const [addDocSpec, setAddDocSpec] = useState<Specialization>('General Physician');
  const [addDocPhone, setAddDocPhone] = useState('');
  const [addDocFees, setAddDocFees] = useState<number>(100);
  const [addDocExpr, setAddDocExpr] = useState<number>(5);
  const [addDocQual, setAddDocQual] = useState('');
  const [addDocAbout, setAddDocAbout] = useState('');
  
  const [addDocVisible, setAddDocVisible] = useState(false);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  // Fetch stats and lists on load or when dependencies refresh
  useEffect(() => {
    if (user && user.role === 'admin') {
      loadAdminStats();
      loadPatientsList();
    }
  }, [user, doctors, appointments]);

  const loadAdminStats = async () => {
    const stats = await adminGetStats();
    if (stats) {
      setPerfStats(stats);
    }
  };

  const loadPatientsList = async () => {
    const list = await adminGetPatients();
    setPatientsList(list);
  };

  if (!user || user.role !== 'admin') {
    return (
      <div className="p-12 text-center text-slate-400 font-sans">
        Administrative authentication credentials trace invalid. Access Blocked.
      </div>
    );
  }

  const handleAddDoctorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addDocName || !addDocEmail || !addDocPassword || !addDocFees) {
      alert("Missing required onboarding fields.");
      return;
    }
    setActionLoading(true);
    const success = await adminAddDoctor({
      name: addDocName,
      email: addDocEmail,
      password: addDocPassword,
      specialization: addDocSpec,
      qualification: addDocQual || 'General Practitioner',
      experience: Number(addDocExpr),
      fees: Number(addDocFees),
      about: addDocAbout || 'Clinical practitioner registered in hospital system.'
    });
    setActionLoading(false);
    if (success) {
      setAddDocName('');
      setAddDocEmail('');
      setAddDocPassword('');
      setAddDocQual('');
      setAddDocAbout('');
      setAddDocVisible(false);
      triggerSuccessBanner("Practitioner catalogued and verified under registers successfully!");
    }
  };

  const triggerSuccessBanner = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(null), 4000);
  };

  const handleApproveDoctor = async (docId: string) => {
    const success = await adminApproveDoctor(docId);
    if (success) {
      triggerSuccessBanner("Practitioner medical credentials approved for clinic operations");
    }
  };

  const handleDeleteDoctor = async (docId: string) => {
    if (confirm("Permanently archive and delete this medical practitioner from CareSync registry logs?")) {
      const success = await adminDeleteDoctor(docId);
      if (success) {
        triggerSuccessBanner("Doctor removed from hospital directories");
      }
    }
  };

  const handleCancelAppointment = async (apptId: string) => {
    if (confirm("As administrator, are you sure you want to cancel this booking reservation?")) {
      const success = await cancelAppointment(apptId);
      if (success) {
        triggerSuccessBanner("Consultation booking canceled safely");
      }
    }
  };

  const specialties: Specialization[] = [
    'Cardiologist',
    'Dentist',
    'Neurologist',
    'Pediatrician',
    'Orthopedic',
    'Dermatologist',
    'General Physician'
  ];

  return (
    <div className="py-10 bg-slate-50 min-h-screen font-sans" id="admin-dashboard-container">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">

        {/* Headline Banner */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900 text-white p-6 rounded-3xl shadow-xs">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-[10px] bg-rose-500/10 text-rose-355 border border-rose-500/20 px-2 py-0.5 rounded-full font-mono uppercase font-bold tracking-widest leading-none">
              Control Station Panel
            </span>
            <h1 className="font-sans font-black text-2xl tracking-tight leading-none text-white">CareSync System Admin</h1>
            <p className="text-slate-400 text-xs text-slate-350">Overview health metrics, manage clinic professionals, and audit booking diaries globally.</p>
          </div>

          <div className="flex gap-2.5">
            <button
              onClick={() => {
                refreshDoctors();
                refreshAppointments();
                loadAdminStats();
                loadPatientsList();
              }}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-xs font-semibold rounded-lg hover:-translate-y-0.5 transition-all text-white cursor-pointer"
            >
              Sync Channels
            </button>
          </div>
        </div>

        {/* Global Operational Success Banner */}
        {actionSuccessMsg && (
          <div className="p-3 bg-emerald-500 text-white font-medium text-xs rounded-xl flex items-center justify-center gap-2 animate-fadeIn" id="admin-success-banner">
            <CheckCircle className="w-4 h-4 text-white" />
            <span>{actionSuccessMsg}</span>
          </div>
        )}

        {/* INNER LAYOUT NAVIGATION DRAWER */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* TAB CHANNEL SHUTTLE (Left Sidebar) */}
          <div className="lg:col-span-3 bg-white p-4 rounded-2xl border border-slate-100 shadow-xs space-y-2">
            
            <button
              onClick={() => setAdminTab('stats')}
              className={`w-full text-left font-sans text-xs font-bold py-2.5 px-4 rounded-xl transition-all cursor-pointer flex items-center gap-2.5 ${
                adminTab === 'stats' 
                  ? 'bg-slate-900 text-white' 
                  : 'text-slate-650 hover:bg-slate-50'
              }`}
            >
              <Activity className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Metrics & Insights</span>
            </button>

            <button
              onClick={() => setAdminTab('doctors')}
              className={`w-full text-left font-sans text-xs font-bold py-2.5 px-4 rounded-xl transition-all cursor-pointer flex items-center gap-2.5 ${
                adminTab === 'doctors' 
                  ? 'bg-slate-900 text-white' 
                  : 'text-slate-650 hover:bg-slate-50'
              }`}
              id="admin-tab-manage-docs"
            >
              <Award className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Manage Clinic Doctors</span>
            </button>

            <button
              onClick={() => setAdminTab('appointments')}
              className={`w-full text-left font-sans text-xs font-bold py-2.5 px-4 rounded-xl transition-all cursor-pointer flex items-center gap-2.5 ${
                adminTab === 'appointments' 
                  ? 'bg-slate-900 text-white' 
                  : 'text-slate-650 hover:bg-slate-50'
              }`}
              id="admin-tab-manage-appt"
            >
              <Calendar className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Audit Bookings ({appointments.length})</span>
            </button>

            <button
              onClick={() => setAdminTab('patients')}
              className={`w-full text-left font-sans text-xs font-bold py-2.5 px-4 rounded-xl transition-all cursor-pointer flex items-center gap-2.5 ${
                adminTab === 'patients' 
                  ? 'bg-slate-900 text-white' 
                  : 'text-slate-650 hover:bg-slate-50'
              }`}
              id="admin-tab-manage-pats"
            >
              <Users className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Patient Directory ({patientsList.length})</span>
            </button>

          </div>

          {/* ACTIVE WORKSPACE AREA (Right Content) */}
          <div className="lg:col-span-9 space-y-6">

            {/* ---------------- DRAW TAB 1: METRICS STATS ---------------- */}
            {adminTab === 'stats' && (
              <div className="space-y-6 animate-fadeIn" id="admin-workspace-stats">
                
                {/* Micro scorecard charts */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  
                  <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
                    <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
                      <Users className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono text-slate-400 uppercase">System Doctors</span>
                      <span className="block text-lg font-black text-slate-900 font-mono">
                        {perfStats?.totalDoctors ?? doctors.length}
                      </span>
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
                    <div className="h-10 w-10 bg-teal-50 text-teal-650 rounded-xl flex items-center justify-center shrink-0">
                      <UserCircle2 className="w-5 h-5 text-teal-500" />
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono text-slate-400 uppercase">Catalogued Patients</span>
                      <span className="block text-lg font-black text-slate-900 font-mono">
                        {perfStats?.totalPatients ?? patientsList.length}
                      </span>
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
                    <div className="h-10 w-10 bg-sky-50 text-sky-600 rounded-xl flex items-center justify-center shrink-0">
                      <Calendar className="w-5 h-5 text-sky-504" />
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono text-slate-400 uppercase">Total Runs</span>
                      <span className="block text-lg font-black text-slate-900 font-mono">
                        {perfStats?.totalAppointments ?? appointments.length}
                      </span>
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
                    <div className="h-10 w-10 bg-rose-50 text-rose-605 rounded-xl flex items-center justify-center shrink-0">
                      <DollarSign className="w-5 h-5 text-emerald-500" />
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono text-slate-400 uppercase">Cumulative Profit</span>
                      <span className="block text-lg font-black text-slate-950 font-mono">
                        ${perfStats?.totalRevenue ?? 0}
                      </span>
                    </div>
                  </div>

                </div>

                {/* Analytical Insights summary list */}
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-4">
                  <h3 className="font-sans font-extrabold text-sm text-slate-900">Hospital Operational Health Indexes</h3>
                  <p className="text-slate-500 text-xs font-sans max-w-lg leading-relaxed">
                    All financial balances are simulated using a pre-configured Stripe ledger. The overall patient counts cover registered profiles with logged diagnostic codes. Wait times remain average below 12 minutes.
                  </p>
                </div>

              </div>
            )}

            {/* ---------------- DRAW TAB 2: MANAGE CLINISTIC DOCTORS ---------------- */}
            {adminTab === 'doctors' && (
              <div className="space-y-6 animate-fadeIn" id="admin-workspace-doctors">
                
                {/* Toolbar bar add button */}
                <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
                  <div>
                    <h3 className="font-sans font-extrabold text-xs sm:text-sm text-slate-900">Medical Staff Ledger</h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">Approve self-registered clinicians or manually onboard medical chairs.</p>
                  </div>
                  <button
                    onClick={() => setAddDocVisible(!addDocVisible)}
                    className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                    id="admin-toggle-add-doc-btn"
                  >
                    {addDocVisible ? <X className="w-3.5 h-3.5" /> : <UserPlus className="w-3.5 h-3.5 text-white" />}
                    <span>{addDocVisible ? 'Dismiss Form' : 'Add New Doctor'}</span>
                  </button>
                </div>

                {/* Form dropdown drawer */}
                {addDocVisible && (
                  <form onSubmit={handleAddDoctorSubmit} className="bg-white border border-slate-150 p-6 rounded-2xl shadow-xs space-y-4 animate-slideDown" id="admin-add-doctor-form">
                    
                    <div className="border-b border-slate-100 pb-2">
                      <h4 className="font-sans font-extrabold text-xs text-slate-950">Credential Placement Registry</h4>
                      <p className="text-[10px] text-slate-400">Add secure credentials for new staff clinical specialists.</p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Practitioner Full Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g., Dr. Mary Cooper"
                          value={addDocName}
                          onChange={(e) => setAddDocName(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden focus:border-emerald-300"
                          id="admin-new-doc-name"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Clinical Specialization</label>
                        <select
                          value={addDocSpec}
                          onChange={(e) => setAddDocSpec(e.target.value as Specialization)}
                          className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden focus:border-emerald-300"
                          id="admin-new-doc-spec"
                        >
                          {specialties.map(s => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Core Board Degrees</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g., MD - Dermatology, Harvard"
                          value={addDocQual}
                          onChange={(e) => setAddDocQual(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-750 outline-hidden focus:border-emerald-300"
                          id="admin-new-doc-qual"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider font-semibold">Sign-In Staff Email Address</label>
                        <input
                          type="email"
                          required
                          placeholder="e.g., mary@caresync.com"
                          value={addDocEmail}
                          onChange={(e) => setAddDocEmail(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-101 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-750 outline-hidden focus:border-emerald-300"
                          id="admin-new-doc-email"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider font-semibold">Secure Password Pin</label>
                        <input
                          type="password"
                          required
                          placeholder="••••••••"
                          value={addDocPassword}
                          onChange={(e) => setAddDocPassword(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-101 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-755 outline-hidden focus:border-emerald-300"
                          id="admin-new-doc-password"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Session Fee ($)</label>
                          <input
                            type="number"
                            min={10}
                            required
                            value={addDocFees}
                            onChange={(e) => setAddDocFees(Number(e.target.value))}
                            className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-755 outline-hidden focus:border-emerald-300"
                            id="admin-new-doc-fees"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Expr (Years)</label>
                          <input
                            type="number"
                            min={1}
                            required
                            value={addDocExpr}
                            onChange={(e) => setAddDocExpr(Number(e.target.value))}
                            className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-755 outline-hidden focus:border-emerald-300"
                            id="admin-new-doc-experience"
                          />
                        </div>
                      </div>

                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Practitioner Biography</label>
                      <textarea
                        rows={3}
                        value={addDocAbout}
                        onChange={(e) => setAddDocAbout(e.target.value)}
                        placeholder="Specify key specialist details or medical backgrounds..."
                        className="w-full bg-slate-50 border border-slate-101 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-750 outline-hidden resize-none focus:border-emerald-300"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={actionLoading}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-semibold py-3 rounded-xl transition-all cursor-pointer text-center uppercase tracking-wider font-mono p-1"
                      id="admin-submit-new-doc"
                    >
                      {actionLoading ? 'Authorized placement processing...' : 'Register Authorized Practitioner'}
                    </button>

                  </form>
                )}

                {/* Listing of clinical professionals */}
                <div className="space-y-4" id="admin-doctors-register-list">
                  {doctors.map((doc) => (
                    <div
                      key={doc.id}
                      className="bg-white border border-slate-100 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-200 transition-all shadow-xs"
                      id={`admin-doc-row-${doc.id}`}
                    >
                      <div className="flex gap-4 items-start">
                        <div className="w-12 h-12 bg-linear-to-tr from-emerald-55 to-teal-5 bg-emerald-5 text-emerald-600 font-sans font-bold text-base flex items-center justify-center rounded-xl shrink-0 border border-emerald-50">
                          {doc.name.split(' ').slice(1).map(n => n[0]).join('') || 'MD'}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-sans font-extrabold text-xs text-slate-900 leading-tight">{doc.name}</h4>
                            <span className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-full border ${
                              doc.approved 
                                ? 'bg-emerald-50 border-emerald-100 text-emerald-705' 
                                : 'bg-rose-50 border-rose-100 text-rose-700 animate-pulse'
                            }`}>
                              {doc.approved ? 'Approved' : 'Pending Verification'}
                            </span>
                          </div>
                          <p className="text-[10px] font-mono text-[#10b981] uppercase font-bold">{doc.specialization} • {doc.qualification}</p>
                          <p className="text-[11px] text-slate-400 font-sans leading-none">Email: {doc.email} • Fee: ${doc.fees}</p>
                        </div>
                      </div>

                      {/* Controls (Approval triggers & deletions) */}
                      <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                        
                        {!doc.approved && (
                          <button
                            onClick={() => handleApproveDoctor(doc.id)}
                            className="px-3 py-1.5 bg-emerald-50 text-emerald-600 hover:bg-emerald-500 hover:text-white rounded-xl text-xs font-semibold cursor-pointer transition-all flex items-center gap-1"
                            id={`approve-doc-btn-${doc.id}`}
                          >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>Verify Credentials</span>
                          </button>
                        )}

                        <button
                          onClick={() => handleDeleteDoctor(doc.id)}
                          className="p-2 text-rose-450 hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-100 rounded-xl transition-all cursor-pointer"
                          title="Archive doctor placement"
                          id={`delete-doc-btn-${doc.id}`}
                        >
                          <Trash2 className="w-4 h-4 text-rose-500" />
                        </button>

                      </div>

                    </div>
                  ))}
                  {doctors.length === 0 && (
                    <p className="text-center text-slate-400 text-xs italic py-8">No hospital clinical professionals are registered yet in database.</p>
                  )}
                </div>

              </div>
            )}

            {/* ---------------- DRAW TAB 3: AUDIT HOSPITAL BOOKINGS ---------------- */}
            {adminTab === 'appointments' && (
              <div className="space-y-6 animate-fadeIn" id="admin-workspace-appointments">
                
                <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
                  <h3 className="font-sans font-extrabold text-sm text-slate-900">Hospital Central Appointments Log</h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">Global audit logs showing active patients, assigned clinicians, and overall payment status.</p>
                </div>

                <div className="space-y-4" id="admin-appointments-register-list">
                  {appointments.map((appt) => (
                    <div
                      key={appt.id}
                      className="bg-white border border-slate-100 p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row sm:items-start justify-between gap-4 hover:border-slate-200 transition-all shadow-xs"
                      id={`admin-appt-row-${appt.id}`}
                    >
                      <div className="space-y-2.5">
                        
                        {/* Summary overview details block */}
                        <div>
                          <span className="text-[9px] font-mono text-slate-400 bg-slate-50 px-1.5 py-0.5 rounded">ID: {appt.id}</span>
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-xs font-sans">
                            <span className="text-slate-905 font-extrabold">Patient: {appt.patientName}</span>
                            <span className="text-slate-350">➔</span>
                            <span className="text-slate-900 font-semibold text-emerald-650">MD: {appt.doctorName} ({appt.doctorSpecialization})</span>
                          </div>
                        </div>

                        {/* Scheduling detail node values */}
                        <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-500 font-sans">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-emerald-500" />
                            <span className="font-mono">{appt.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-emerald-500" />
                            <span className="font-mono">{appt.timeSlot}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
                            <span className="font-mono">Billing: ${appt.fee}</span>
                          </div>
                        </div>

                        {/* Badges row */}
                        <div className="flex flex-wrap items-center gap-1.5">
                          
                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase border ${
                            appt.status === 'Upcoming' 
                              ? 'bg-sky-50 border-sky-100 text-sky-700'
                              : appt.status === 'Completed'
                              ? 'bg-amber-50 border-amber-100 text-amber-707'
                              : 'bg-rose-50 border-rose-100 text-rose-700 line-through'
                          }`}>
                            {appt.status}
                          </span>

                          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase border ${
                            appt.paymentStatus === 'Paid'
                              ? 'bg-emerald-50 border-emerald-100 text-emerald-707 font-medium'
                              : 'bg-amber-50 border-amber-100 text-amber-705'
                          }`}>
                            💳 {appt.paymentStatus}
                          </span>

                          {appt.transactionId && (
                            <span className="text-[9px] font-mono text-slate-404">
                              Txn: {appt.transactionId}
                            </span>
                          )}

                        </div>

                      </div>

                      {/* Cancellation controls */}
                      {appt.status === 'Upcoming' && (
                        <button
                          onClick={() => handleCancelAppointment(appt.id)}
                          className="bg-rose-50 hover:bg-[#ffe3e3] border border-rose-150 text-rose-600 font-bold text-[11px] px-3.5 py-1.5 rounded-xl transition-colors cursor-pointer self-end sm:self-start shrink-0"
                          id={`cancel-appt-btn-${appt.id}`}
                        >
                          Cancel Booking
                        </button>
                      )}

                    </div>
                  ))}
                  {appointments.length === 0 && (
                    <p className="text-center text-slate-400 text-xs italic py-8">No hospital appointments catalogued yet.</p>
                  )}
                </div>

              </div>
            )}

            {/* ---------------- DRAW TAB 4: LIST OF REGISTERED PATIENTS ---------------- */}
            {adminTab === 'patients' && (
              <div className="space-y-6 animate-fadeIn" id="admin-workspace-patients">
                
                <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs">
                  <h3 className="font-sans font-extrabold text-sm text-slate-900">Hospital Register of Patients</h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">Directory list of active family health profiles compiled globally from the registration database page.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="admin-patients-register-list">
                  {patientsList.map((pat) => (
                    <div 
                      key={pat.id}
                      className="bg-white border border-slate-100 p-4 rounded-2xl flex items-start gap-3.5 hover:border-slate-205 transition-all shadow-xs"
                      id={`admin-patient-card-${pat.id}`}
                    >
                      <div className="h-10 w-10 font-bold bg-linear-to-tr from-sky-50 to-indigo-5 text-sky-650 rounded-xl flex items-center justify-center shrink-0 border border-sky-50">
                        {pat.name[0]}
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-sans font-extrabold text-xs text-slate-900 leading-tight">{pat.name}</h4>
                        <p className="text-[10px] font-mono text-slate-400">Biological Sex: {pat.gender} • Age: {pat.age} Yrs</p>
                        <ul className="text-[11px] text-slate-405 font-sans leading-none space-y-1 pt-1">
                          <li>Contact: {pat.phone || 'Not Specified'}</li>
                          <li>Email: {pat.email}</li>
                          <li>Triage Code: <strong className="font-mono text-slate-700">{pat.id}</strong></li>
                        </ul>
                      </div>
                    </div>
                  ))}
                  {patientsList.length === 0 && (
                    <p className="text-center text-slate-400 text-xs italic py-8 md:col-span-2">No active patients registered yet in database.</p>
                  )}
                </div>

              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
export default AdminDashboard;
