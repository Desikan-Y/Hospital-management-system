import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Doctor, Appointment } from '../types';

interface AppContextType {
  user: (User | Doctor) | null;
  token: string | null;
  activeView: string;
  selectedDoctorId: string | null;
  doctors: Doctor[];
  appointments: Appointment[];
  loading: boolean;
  error: string | null;
  setView: (view: string, doctorId?: string | null) => void;
  login: (email: string, password: string, role: string) => Promise<boolean>;
  registerPatient: (data: any) => Promise<boolean>;
  logout: () => void;
  updateProfile: (data: any) => Promise<boolean>;
  refreshDoctors: () => Promise<void>;
  refreshAppointments: () => Promise<void>;
  bookAppointment: (doctorId: string, date: string, timeSlot: string) => Promise<any>;
  payAppointment: (appointmentId: string) => Promise<boolean>;
  cancelAppointment: (appointmentId: string) => Promise<boolean>;
  completeAppointment: (appointmentId: string) => Promise<boolean>;
  
  // admin specific
  adminAddDoctor: (data: any) => Promise<boolean>;
  adminApproveDoctor: (doctorId: string) => Promise<boolean>;
  adminDeleteDoctor: (doctorId: string) => Promise<boolean>;
  adminUpdateDoctor: (doctorId: string, data: any) => Promise<boolean>;
  adminGetStats: () => Promise<any>;
  adminGetPatients: () => Promise<User[]>;
  setError: (err: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<(User | Doctor) | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('doc_app_token'));
  const [activeView, setActiveView] = useState<string>('home');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string | null>(null);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize and load base context data
  useEffect(() => {
    refreshDoctors();
    if (token) {
      loadCurrentUser(token);
    }
  }, [token]);

  const setView = (view: string, doctorId: string | null = null) => {
    setActiveView(view);
    if (doctorId) {
      setSelectedDoctorId(doctorId);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const loadCurrentUser = async (authToken: string) => {
    try {
      setLoading(true);
      const res = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${authToken}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        refreshAppointments();
      } else {
        // Bad token
        logout();
      }
    } catch (err) {
      console.error("Failed to load current session", err);
    } finally {
      setLoading(false);
    }
  };

  const refreshDoctors = async () => {
    try {
      const res = await fetch('/api/doctors');
      if (res.ok) {
        const data = await res.json();
        setDoctors(data);
      }
    } catch (err) {
      console.error("Failed to fetch medical listing", err);
    }
  };

  const refreshAppointments = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/appointments', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setAppointments(data);
      }
    } catch (err) {
      console.error("Failed to fetch appointment rosters", err);
    }
  };

  const login = async (email: string, password: string, role: string): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, role })
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Login validation failed");
        return false;
      }
      localStorage.setItem('doc_app_token', data.token);
      setToken(data.token);
      setUser(data.user);
      setView(data.user.role === 'admin' || data.user.role === 'doctor' ? 'dashboard' : 'home');
      return true;
    } catch (err) {
      setError("Server connectivity offline");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const registerPatient = async (patientData: any): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patientData)
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Registration validation error");
        return false;
      }
      localStorage.setItem('doc_app_token', data.token);
      setToken(data.token);
      setUser(data.user);
      setView('home');
      return true;
    } catch (err) {
      setError("Registration server connection timed out");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('doc_app_token');
    setToken(null);
    setUser(null);
    setAppointments([]);
    setView('home');
  };

  const updateProfile = async (profileData: any): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(profileData)
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Profile updating failed");
        return false;
      }
      setUser(data.user);
      refreshDoctors(); // If doctor updated profile
      return true;
    } catch (err) {
      setError("Profile synchronization error");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const bookAppointment = async (doctorId: string, date: string, timeSlot: string): Promise<any> => {
    if (!token) {
      setError("Please sign in or register to schedule appointments");
      return null;
    }
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ doctorId, date, timeSlot })
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to make slot reservation");
        return null;
      }
      await refreshAppointments();
      return data.appointment;
    } catch (err) {
      setError("Appointment gateway connection failed");
      return null;
    } finally {
      setLoading(false);
    }
  };

  const payAppointment = async (appointmentId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      const res = await fetch(`/api/appointments/${appointmentId}/pay`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        await refreshAppointments();
        return true;
      } else {
        const data = await res.json();
        setError(data.error || "Payment transaction processing abandoned");
        return false;
      }
    } catch (err) {
      setError("Secure checkout connection offline");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const cancelAppointment = async (appointmentId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      const res = await fetch(`/api/appointments/${appointmentId}/cancel`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        await refreshAppointments();
        return true;
      } else {
        const data = await res.json();
        setError(data.error || "Failed to cancel appointment");
        return false;
      }
    } catch (err) {
      setError("Cancellation gateway offline");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const completeAppointment = async (appointmentId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      const res = await fetch(`/api/appointments/${appointmentId}/complete`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (res.ok) {
        await refreshAppointments();
        return true;
      }
      return false;
    } catch (err) {
      setError("Completion state sync failed");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Admin CRUD methods
  const adminAddDoctor = async (doctorData: any): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/doctors', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(doctorData)
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to catalog doctor listing");
        return false;
      }
      await refreshDoctors();
      return true;
    } catch (err) {
      setError("Registration terminal failed");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const adminApproveDoctor = async (doctorId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      const res = await fetch(`/api/doctors/${doctorId}/approve`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        await refreshDoctors();
        return true;
      }
      return false;
    } catch (err) {
      return false;
    } finally {
      setLoading(false);
    }
  };

  const adminDeleteDoctor = async (doctorId: string): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      const res = await fetch(`/api/doctors/${doctorId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        await refreshDoctors();
        return true;
      }
      return false;
    } catch (err) {
      return false;
    } finally {
      setLoading(false);
    }
  };

  const adminUpdateDoctor = async (doctorId: string, updatedData: any): Promise<boolean> => {
    if (!token) return false;
    try {
      setLoading(true);
      const res = await fetch(`/api/doctors/${doctorId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updatedData)
      });
      if (res.ok) {
        await refreshDoctors();
        return true;
      }
      return false;
    } catch (err) {
      return false;
    } finally {
      setLoading(false);
    }
  };

  const adminGetStats = async (): Promise<any> => {
    if (!token) return null;
    try {
      const res = await fetch('/api/admin/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) return await res.json();
    } catch (err) {
      console.error("Admin metrics sync offline", err);
    }
    return null;
  };

  const adminGetPatients = async (): Promise<User[]> => {
    if (!token) return [];
    try {
      const res = await fetch('/api/admin/patients', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) return await res.json();
    } catch (err) {
      console.error("Patient analytics directories offline", err);
    }
    return [];
  };

  return (
    <AppContext.Provider value={{
      user,
      token,
      activeView,
      selectedDoctorId,
      doctors,
      appointments,
      loading,
      error,
      setView,
      login,
      registerPatient,
      logout,
      updateProfile,
      refreshDoctors,
      refreshAppointments,
      bookAppointment,
      payAppointment,
      cancelAppointment,
      completeAppointment,
      adminAddDoctor,
      adminApproveDoctor,
      adminDeleteDoctor,
      adminUpdateDoctor,
      adminGetStats,
      adminGetPatients,
      setError
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be accessed inside AppProvider wrapper');
  }
  return context;
};
