import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, HelpCircle, CheckCircle2 } from 'lucide-react';

export const ContactView: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      alert("Please key in your name, email, and description message.");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 1000);
  };

  return (
    <div className="py-12 bg-slate-50 min-h-screen animate-fadeIn" id="contact-page-view">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">

        {/* Heading */}
        <div className="text-center space-y-2 mb-10">
          <span className="text-[10px] font-mono tracking-widest text-[#10b981] font-bold uppercase p-1 px-2.5 bg-emerald-50 rounded-full">
            Inquiries Gateway
          </span>
          <h1 className="font-sans font-bold text-3xl text-slate-900 tracking-tight">Connect With Our Medical Group</h1>
          <p className="text-slate-500 font-sans text-xs max-w-sm mx-auto">
            Need consultation clarifications, feedback, or administrative billing adjustments? Get in touch immediately.
          </p>
        </div>

        {/* Main Content Layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* Direct Address Column */}
          <div className="md:col-span-5 space-y-6">
            
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-6">
              
              <h3 className="font-sans font-bold text-sm text-slate-900 uppercase font-mono tracking-wider">
                Clinic Location
              </h3>

              <div className="space-y-4">
                
                <div className="flex gap-3">
                  <div className="h-8 w-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="text-xs font-sans text-slate-500">
                    <strong className="block text-slate-900">Hospital Headquarters</strong>
                    CareSync Clinics Plaza<br />
                    100 Medical Plaza, Suite 400<br />
                    Boston, MA 02116
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="h-8 w-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="text-xs font-sans text-slate-500">
                    <strong className="block text-slate-900">Direct Care Hotline</strong>
                    +1 (555) 390-4820 (Toll Free)<br />
                    Monday – Friday, 8am – 5pm
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="h-8 w-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <Mail className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="text-xs font-sans text-slate-500">
                    <strong className="block text-slate-900">Digital Correspondence</strong>
                    support@caresyncclinics.com<br />
                    billing@caresyncclinics.com
                  </div>
                </div>

              </div>

            </div>

            {/* Simulated Triage Warning */}
            <div className="bg-[#fff5f5] border border-rose-100 p-4 rounded-xl flex items-start gap-2.5">
              <HelpCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              <div className="text-[11px] font-sans text-rose-800 leading-relaxed">
                👩‍⚕️ <strong>Emergency Note:</strong> This intake feedback form is for non-critical scheduling requests. If you are experiencing a life-threatening crisis, dial <strong>911</strong> or find your nearest hospital emergency department immediately.
              </div>
            </div>

          </div>

          {/* Intake Submission Form */}
          <div className="md:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-slate-100 shadow-xs">
            
            {success ? (
              <div className="text-center py-8 space-y-3" id="contact-submission-success">
                <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-emerald-100 text-emerald-600">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                </div>
                <h3 className="font-sans font-bold text-sm text-slate-900">Intake Submission Logged</h3>
                <p className="text-xs text-slate-400 font-sans max-w-sm mx-auto leading-relaxed">
                  Our system dispatch has received your inquiry. A patient coordination manager aims to email/phone you within standard clinical working status intervals.
                </p>
                <button
                  type="button"
                  onClick={() => setSuccess(false)}
                  className="mt-2 text-xs font-semibold text-emerald-605 underline cursor-pointer"
                >
                  Submit another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4" id="hospital-contact-form">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Your Name <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g., John Doe"
                      className="w-full bg-slate-50/60 border border-slate-100 focus:border-emerald-300 px-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                      id="contact-name-input"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Email Address <span className="text-rose-500">*</span></label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g., john@demo.com"
                      className="w-full bg-slate-50/60 border border-slate-100 focus:border-emerald-300 px-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                      id="contact-email-input"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Topic Subject</label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="e.g., Appointment rescheduling assistance"
                    className="w-full bg-slate-50/60 border border-slate-100 focus:border-emerald-300 px-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="contact-subject-input"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Detailed Message <span className="text-rose-500">*</span></label>
                  <textarea
                    rows={4}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Please specify how CareSync administrative offices can assist you today..."
                    className="w-full bg-slate-50/60 border border-slate-100 focus:border-emerald-300 px-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden resize-none"
                    id="contact-message-input"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-semibold py-3 rounded-xl transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                  id="contact-submit-btn"
                >
                  <Send className="w-3.5 h-3.5 text-emerald-450" />
                  <span>{loading ? 'Submitting Form...' : 'Dispatch Intake Request'}</span>
                </button>

              </form>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
export default ContactView;
