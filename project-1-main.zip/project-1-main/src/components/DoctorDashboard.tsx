import React, { useState, useEffect } from 'react';
import { useApp } from './AppContext';
import { ClipboardCheck, Sparkles, User, Briefcase, ThumbsUp, DollarSign, Clock, CheckSquare, Calendar, RefreshCw, XCircle } from 'lucide-react';
import { Appointment } from '../types';

export const DoctorDashboard: React.FC = () => {
  const { 
    user, 
    appointments, 
    updateProfile, 
    cancelAppointment, 
    completeAppointment, 
    refreshAppointments 
  } = useApp();

  // Profile Edit fields for Doctor
  const [docFees, setDocFees] = useState<number>(100);
  const [docExpr, setDocExpr] = useState<number>(5);
  const [docAbout, setDocAbout] = useState('');
  const [docTimings, setDocTimings] = useState<string[]>([]);
  const [timingChoiceInput, setTimingChoiceInput] = useState('');

  const [editSuccess, setEditSuccess] = useState(false);
  const [editLoading, setEditLoading] = useState(false);

  // Filter selection tabs
  const [selectedLogTab, setSelectedLogTab] = useState<'all' | 'upcoming' | 'finished'>('all');

  useEffect(() => {
    if (user && user.role === 'doctor') {
      const doc = user as any;
      setDocFees(doc.fees || 100);
      setDocExpr(doc.experience || 5);
      setDocAbout(doc.about || '');
      setDocTimings(doc.timings || []);
    }
  }, [user]);

  if (!user || user.role !== 'doctor') {
    return (
      <div className="p-12 text-center text-slate-400 font-sans">
        Doctor access token validation failed.
      </div>
    );
  }

  // Calculate Doctor metrics
  const doctorAppointments = appointments;
  const totalMyAppointments = doctorAppointments.length;
  
  const totalMyEarnings = doctorAppointments
    .filter(a => a.paymentStatus === 'Paid' && a.status !== 'Cancelled')
    .reduce((sum, a) => sum + a.fee, 0);

  const pendingAppointments = doctorAppointments.filter(a => a.status === 'Upcoming').length;

  const completedSessionCount = doctorAppointments.filter(a => a.status === 'Completed').length;

  const filteredAppointments = doctorAppointments.filter(a => {
    if (selectedLogTab === 'upcoming') {
      return a.status === 'Upcoming';
    } else if (selectedLogTab === 'finished') {
      return a.status === 'Completed' || a.status === 'Cancelled';
    }
    return true; // value 'all'
  });

  const handleDocProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setEditLoading(true);
    setEditSuccess(false);

    const success = await updateProfile({
      about: docAbout,
      fees: Number(docFees),
      experience: Number(docExpr),
      timings: docTimings
    });

    setEditLoading(false);
    if (success) {
      setEditSuccess(true);
      setTimeout(() => setEditSuccess(false), 3000);
    }
  };

  const handleTimingAdd = () => {
    if (!timingChoiceInput.trim()) return;
    if (docTimings.includes(timingChoiceInput.trim())) return;
    setDocTimings([...docTimings, timingChoiceInput.trim()]);
    setTimingChoiceInput('');
  };

  const handleTimingRemove = (tIdx: number) => {
    setDocTimings(docTimings.filter((_, idx) => idx !== tIdx));
  };

  return (
    <div className="py-10 bg-slate-50 min-h-screen font-sans" id="doctor-dashboard-container">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Welcome / Header intro panel */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white border border-slate-100 p-6 rounded-3xl shadow-xs">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-[10px] font-mono tracking-widest text-[#10b981] font-bold uppercase">MD Practitioners Panel</span>
            <h1 className="font-sans font-black text-2xl text-slate-900 tracking-tight leading-none">
              Welcome back, {user.name}
            </h1>
            <p className="text-slate-500 text-xs">Medical specialty checkups, operational billings, and consultations coordinator.</p>
          </div>
          
          <button
            onClick={() => refreshAppointments()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-all cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500 animate-spin-once" />
            <span>Sync Hospital Logs</span>
          </button>
        </div>

        {/* 1. PRACTITIONER METRICS ROW */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
              <ClipboardCheck className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">My Total Bookings</span>
              <span className="block text-lg font-black text-slate-900 font-mono">{totalMyAppointments}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
              <DollarSign className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">Total MD Income</span>
              <span className="block text-lg font-black text-slate-900 font-mono">${totalMyEarnings}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-sky-50 text-teal-600 rounded-xl flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5 text-teal-500" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">Awaiting Diagnosis</span>
              <span className="block text-lg font-black text-slate-900 font-mono">{pendingAppointments}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center shrink-0">
              <ThumbsUp className="w-5 h-5 text-emerald-550" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">Completed Sessions</span>
              <span className="block text-lg font-black text-slate-900 font-mono">{completedSessionCount}</span>
            </div>
          </div>

        </div>

        {/* 2. CORE DUAL SECTION: MANAGE CLINICAL DIRECTORY & INTAKE APPOINTMENTS */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* PROFILE CREDS CONFIG (Left Column) */}
          <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-6">
            
            <div className="border-b border-slate-100 pb-3">
              <h3 className="font-sans font-extrabold text-sm text-slate-900">Manage Clinical Profile</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">Control consultant fees, experience levels, & hourly schedules</p>
            </div>

            <form onSubmit={handleDocProfileSave} className="space-y-4" id="doctor-profile-update-form">
              
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Session Fee ($)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={docFees}
                    onChange={(e) => setDocFees(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-100 focus:border-emerald-300 px-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="doctor-profile-fees"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Active Exp (Yrs)</label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={docExpr}
                    onChange={(e) => setDocExpr(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-100 focus:border-emerald-300 px-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="doctor-profile-experience"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Public Biography 'About'</label>
                <textarea
                  rows={4}
                  required
                  value={docAbout}
                  onChange={(e) => setDocAbout(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-105 focus:border-emerald-300 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden resize-none leading-relaxed"
                  id="doctor-profile-about"
                />
              </div>

              {/* Dynamic timings tags config */}
              <div className="space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Scheduled Daily Hour Slots</label>
                
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g., 09:30 AM"
                    value={timingChoiceInput}
                    onChange={(e) => setTimingChoiceInput(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-xl text-xs font-sans placeholder-slate-400 outline-hidden focus:border-emerald-300"
                    id="doctor-new-time-slot-input"
                  />
                  <button
                    type="button"
                    onClick={handleTimingAdd}
                    className="px-3 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800 cursor-pointer"
                  >
                    Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {docTimings.map((timeSlot, tIdx) => (
                    <span 
                      key={timeSlot}
                      className="inline-flex items-center gap-1 bg-slate-50 border border-slate-200 text-slate-750 text-[10px] px-2 py-1 rounded-md"
                    >
                      <span>{timeSlot}</span>
                      <button
                        type="button"
                        onClick={() => handleTimingRemove(tIdx)}
                        className="text-rose-500 hover:text-rose-700 font-bold ml-1.5 cursor-pointer text-xs leading-none"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                  {docTimings.length === 0 && (
                    <span className="text-[10px] text-slate-400 italic">No scheduled timings configured. Default clinical slot ranges will apply.</span>
                  )}
                </div>
              </div>

              {editSuccess && (
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-650 font-bold text-[11px] text-center" id="profile-edit-success-alert">
                  ✓ Clinic practitioner profile updated safely!
                </div>
              )}

              <button
                type="submit"
                disabled={editLoading}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-sans text-xs font-bold uppercase tracking-wider py-3 rounded-xl transition-all shadow-xs cursor-pointer text-center"
                id="save-doctor-profile-btn"
              >
                {editLoading ? 'Publishing credentials...' : 'Publish Update'}
              </button>

            </form>

          </div>

          {/* ACTIVE INTAKE APPOINTMENTS REGISTER (Right Column) */}
          <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-sans font-extrabold text-sm text-slate-900">Patient Case Logs</h3>
                <p className="text-[10px] text-slate-400 mt-0.5">Manage schedule statuses and record diagnoses</p>
              </div>

              {/* Filtering category tabs */}
              <div className="flex gap-1 bg-slate-50 p-1 rounded-lg border border-slate-100">
                {(['all', 'upcoming', 'finished'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setSelectedLogTab(tab)}
                    className={`px-3 py-1 text-[10px] font-bold uppercase rounded-md transition-all cursor-pointer ${
                      selectedLogTab === tab
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'text-slate-450 hover:text-slate-800'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* List entries */}
            {filteredAppointments.length === 0 ? (
              <div className="p-12 text-center border-2 border-dashed border-slate-100 rounded-3xl">
                <p className="text-slate-400 text-xs italic font-sans animate-pulse">No active case logs match this selected category.</p>
              </div>
            ) : (
              <div className="space-y-4" id="doctor-appointments-list">
                {filteredAppointments.map((appt) => (
                  <div
                    key={appt.id}
                    className="border border-slate-100 p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row sm:items-start justify-between gap-4 hover:border-slate-200 transition-all"
                    id={`appt-doctor-item-${appt.id}`}
                  >
                    <div className="space-y-2.5">
                      
                      {/* Patient details header */}
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full bg-linear-to-tr from-teal-50 to-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-sm shrink-0 border border-emerald-50">
                          {appt.patientName[0]}
                        </div>
                        <div>
                          <h4 className="font-sans font-semibold text-xs text-slate-900 leading-tight">Patient: {appt.patientName}</h4>
                          <span className="block text-[10px] text-slate-400">
                            Age: {appt.patientAge} • Sex: Male/Female • Code: <strong className="font-mono">{appt.patientId}</strong>
                          </span>
                        </div>
                      </div>

                      {/* Detail metrics */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-1.5 text-xs font-sans text-slate-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="font-mono">{appt.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="font-mono">{appt.timeSlot}</span>
                        </div>
                        <div className="flex items-center gap-1 col-span-2">
                          <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mr-1">Phone:</span>
                          <span className="font-mono leading-none">{appt.patientPhone}</span>
                        </div>
                      </div>

                      {/* Status Badges line */}
                      <div className="flex flex-wrap items-center gap-2">
                        
                        {/* Attendance State */}
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase border ${
                          appt.status === 'Upcoming' 
                            ? 'bg-sky-50 border-sky-100 text-sky-700'
                            : appt.status === 'Completed'
                            ? 'bg-amber-50 border-amber-100 text-amber-707'
                            : 'bg-rose-50 border-rose-100 text-rose-700 line-through'
                        }`}>
                          {appt.status}
                        </span>

                        {/* Payment Billing Clearance */}
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase border ${
                          appt.paymentStatus === 'Paid'
                            ? 'bg-emerald-50 border-emerald-100 text-emerald-700 font-medium'
                            : 'bg-amber-50 border-amber-100 text-amber-705'
                        }`}>
                          {appt.paymentStatus}
                        </span>

                        {appt.transactionId && (
                          <span className="text-[9px] font-mono text-slate-400">
                            Txn: {appt.transactionId}
                          </span>
                        )}

                      </div>

                    </div>

                    {/* Active Action triggers (Cancellation / Complete) */}
                    {appt.status === 'Upcoming' && (
                      <div className="flex sm:flex-col gap-1.5 shrink-0">
                        
                        <button
                          onClick={async () => {
                            if (confirm("Mark this consultation diagnosis as Complete?")) {
                              await completeAppointment(appt.id);
                            }
                          }}
                          className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-[11px] px-3.5 py-1.5 rounded-xl transition-all cursor-pointer shadow-xs whitespace-nowrap text-center flex items-center justify-center gap-1"
                          id={`complete-appt-btn-${appt.id}`}
                        >
                          <CheckSquare className="w-3.5 h-3.5 text-white" />
                          <span>Complete Session</span>
                        </button>

                        <button
                          onClick={async () => {
                            if (confirm("Reject or cancel this patient visit block of time?")) {
                              await cancelAppointment(appt.id);
                            }
                          }}
                          className="bg-rose-50 hover:bg-rose-100/90 border border-rose-150 text-rose-600 font-semibold text-[11px] px-3.5 py-1.5 rounded-xl transition-colors cursor-pointer text-center"
                          id={`cancel-appt-btn-${appt.id}`}
                        >
                          Reject Request
                        </button>

                      </div>
                    )}

                  </div>
                ))}
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
export default DoctorDashboard;
