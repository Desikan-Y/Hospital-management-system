import React, { useState, useEffect } from 'react';
import { useApp } from './AppContext';
import { Search, SlidersHorizontal, Calendar, Clock, DollarSign, Award, ChevronLeft, ShieldCheck, Heart, User } from 'lucide-react';
import { Specialization, Doctor } from '../types';

export const DoctorsView: React.FC = () => {
  const { 
    doctors, 
    selectedDoctorId, 
    setView, 
    bookAppointment, 
    payAppointment,
    user 
  } = useApp();

  // Search & Filter state
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('');

  // Booking Flow temporary state
  const [bookingDate, setBookingDate] = useState<string>('');
  const [bookingTime, setBookingTime] = useState<string>('');
  const [bookingStep, setBookingStep] = useState<'profile' | 'summary' | 'payment'>('profile');
  const [createdAppointmentId, setCreatedAppointmentId] = useState<string | null>(null);
  
  // Payment simulations
  const [paymentLoading, setPaymentLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Check if a filter was requested on homepage
  useEffect(() => {
    const savedFilter = localStorage.getItem('selected_specialty_filter');
    if (savedFilter) {
      setSelectedSpecialty(savedFilter);
      localStorage.removeItem('selected_specialty_filter');
    }
  }, []);

  // Filter list of approved doctors
  const filteredDoctors = doctors.filter(doc => {
    if (!doc.approved) return false;
    
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          doc.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          doc.qualification.toLowerCase().includes(searchTerm.toLowerCase());
                          
    const matchesSpecialty = selectedSpecialty === '' || doc.specialization === selectedSpecialty;
    
    return matchesSearch && matchesSpecialty;
  });

  const activeDoctor = doctors.find(d => d.id === selectedDoctorId);

  // Reset booking flags
  const handleSelectDoctor = (docId: string) => {
    setView('doctors', docId);
    setBookingDate('');
    setBookingTime('');
    setBookingStep('profile');
    setCreatedAppointmentId(null);
    setPaymentSuccess(false);
  };

  const handleClearDoctorSelection = () => {
    setView('doctors', null);
  };

  // Check weekday mapping
  const getDayName = (dateString: string): string => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { weekday: 'long' });
  };

  const isDayAvailable = (dateString: string, doctor: Doctor): boolean => {
    if (!dateString) return true;
    const dayName = getDayName(dateString);
    return doctor.availability.includes(dayName);
  };

  const handleCreateAppointment = async () => {
    if (!activeDoctor) return;
    if (!bookingDate) {
      alert("Please select a calendar date for consultation");
      return;
    }
    if (!bookingTime) {
      alert("Please select an available afternoon or morning slot");
      return;
    }

    if (!user) {
      alert("Authenticated patient record required! Redirecting to login gateway.");
      setView('login');
      return;
    }

    if (user.role !== 'patient') {
      alert("Admins and Medical Staff are restricted from scheduling consultations");
      return;
    }

    // Attempt booking
    const appt = await bookAppointment(activeDoctor.id, bookingDate, bookingTime);
    if (appt) {
      setCreatedAppointmentId(appt.id);
      setBookingStep('payment');
    }
  };

  const handleProcessPayment = async () => {
    if (!createdAppointmentId) return;
    setPaymentLoading(true);
    
    // Simulate transaction delay
    setTimeout(async () => {
      const success = await payAppointment(createdAppointmentId);
      setPaymentLoading(false);
      if (success) {
        setPaymentSuccess(true);
      }
    }, 1500);
  };

  const specialties: Specialization[] = [
    'Cardiologist',
    'Dentist',
    'Neurologist',
    'Pediatrician',
    'Orthopedic',
    'Dermatologist',
    'General Physician'
  ];

  return (
    <div className="py-10 bg-slate-50 min-h-screen" id="doctors-page-view">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* ---------------- A) SINGLE DOCTOR DETAIL VIEW (IF SELECTED) ---------------- */}
        {activeDoctor ? (
          <div className="space-y-6 max-w-4xl mx-auto" id="selected-doctor-profile">
            
            {/* Back to listings bar */}
            <button
              onClick={handleClearDoctorSelection}
              className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 font-semibold transition-colors cursor-pointer"
              id="back-to-docs-btn"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Back to Doctors Directory</span>
            </button>

            {/* Main Doctor Dashboard Widget */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              
              {/* Doctor Details (MD Profile specs) */}
              <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-100 shadow-xs md:col-span-7 space-y-6">
                
                <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center">
                  <div className="w-20 h-20 rounded-2xl bg-linear-to-tr from-emerald-100 to-teal-50 text-emerald-600 flex items-center justify-center font-sans font-bold text-2xl shrink-0 border border-emerald-50">
                    {activeDoctor.name.split(' ').slice(1).map(n => n[0]).join('') || 'MD'}
                  </div>
                  <div>
                    <span className="text-[10px] font-mono tracking-widest text-[#10b981] font-bold uppercase py-0.5 px-2 bg-emerald-50 rounded-full border border-emerald-100">
                      Approved Specialist
                    </span>
                    <h2 className="font-sans font-extrabold text-xl text-slate-900 mt-1">{activeDoctor.name}</h2>
                    <p className="text-xs font-mono text-emerald-600 font-semibold">{activeDoctor.specialization} • {activeDoctor.qualification}</p>
                    <p className="text-[11px] text-slate-400 font-sans mt-0.5">Registration: Board Certified ({activeDoctor.experience} Yrs Active Practice)</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-sans font-bold text-xs text-slate-900 uppercase tracking-wider font-mono">Medical Biography</h3>
                  <p className="font-sans text-xs text-slate-500 leading-relaxed">
                    {activeDoctor.about}
                  </p>
                </div>

                {/* Meta details checklist */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-50 text-xs font-sans">
                  <div>
                    <span className="block text-[9px] text-slate-400 font-mono">CONSULTATION FEE</span>
                    <span className="text-slate-900 font-bold font-mono text-sm">${activeDoctor.fees} / Session</span>
                  </div>
                  <div>
                    <span className="block text-[9px] text-slate-400 font-mono">STAFF ACCOUNT STATUS</span>
                    <span className="text-emerald-600 font-semibold flex items-center gap-1 mt-0.5">
                      <ShieldCheck className="w-4 h-4 shrink-0" /> Verified Practitioner
                    </span>
                  </div>
                </div>

                {/* Availability Weekdays summary */}
                <div className="space-y-2">
                  <h4 className="font-sans font-bold text-xs text-slate-900 font-mono uppercase tracking-wider">Weekly In-Clinic Days</h4>
                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day) => {
                      const isAvailable = activeDoctor.availability.includes(day);
                      return (
                        <span 
                          key={day}
                          className={`text-[10px] px-2.5 py-1 rounded-md font-sans border ${
                            isAvailable 
                              ? 'bg-emerald-50 border-emerald-100 text-emerald-700 font-medium' 
                              : 'bg-slate-50 border-slate-100 text-slate-300 line-through'
                          }`}
                        >
                          {day.substring(0, 3)}
                        </span>
                      );
                    })}
                  </div>
                </div>

              </div>

              {/* Booking & Checkout Wizard Pane */}
              <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-xs md:col-span-5 space-y-5">
                
                {bookingStep === 'profile' && (
                  <div className="space-y-4" id="booking-step-profile">
                    
                    <div className="border-b border-rose-50 pb-3">
                      <h3 className="font-sans font-bold text-sm text-slate-900">Configure Reservation</h3>
                      <p className="text-[10px] text-slate-400 mt-0.5">Select a validated in-clinic timing</p>
                    </div>

                    {/* Date select picker */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">
                        1. Clinic Visit Date
                      </label>
                      <div className="relative">
                        <input
                          type="date"
                          value={bookingDate}
                          min={new Date(Date.now() + 86400000).toISOString().split('T')[0]} // from tomorrow onwards
                          onChange={(e) => {
                            setBookingDate(e.target.value);
                            setBookingTime('');
                          }}
                          className="w-full bg-slate-50/50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-700 outline-hidden focus:border-emerald-300"
                          id="booking-date-picker"
                        />
                      </div>
                      {bookingDate && (
                        <div className="text-[10px] font-sans">
                          {isDayAvailable(bookingDate, activeDoctor) ? (
                            <span className="text-emerald-600 font-medium bg-emerald-50/50 px-2 py-0.5 rounded-md flex items-center gap-1 w-fit mt-1">
                              ✓ {activeDoctor.name} is scheduled on {getDayName(bookingDate)}s
                            </span>
                          ) : (
                            <span className="text-rose-550 font-medium bg-rose-50/50 px-2 py-0.5 rounded-md flex items-center gap-1 w-fit mt-1">
                              ⚠ Doctor not present on {getDayName(bookingDate)}s (See active days)
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Time slots select grid */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">
                        2. Consultation Hour
                      </label>
                      {!bookingDate ? (
                        <p className="text-[10px] text-slate-400 font-sans italic bg-slate-50 p-2.5 rounded-lg text-center">
                          Please determine a calendar date first
                        </p>
                      ) : !isDayAvailable(bookingDate, activeDoctor) ? (
                        <div className="bg-rose-50/30 p-3 rounded-xl text-center border border-rose-100/30">
                          <p className="text-[10px] font-medium text-rose-600">The selected doctor does not schedule appointments on this day of the week.</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-2 mt-1">
                          {activeDoctor.timings.map((time) => (
                            <button
                              key={time}
                              onClick={() => setBookingTime(time)}
                              className={`py-2 rounded-lg text-xs font-sans font-semibold transition-all cursor-pointer border ${
                                bookingTime === time
                                  ? 'bg-slate-900 border-slate-900 text-white shadow-xs'
                                  : 'bg-white border-slate-200 text-slate-700 hover:border-slate-355 hover:bg-slate-50'
                              }`}
                              id={`time-slot-${time.replace(' ', '-').replace(':', '')}`}
                            >
                              {time}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    <button
                      onClick={handleCreateAppointment}
                      disabled={!bookingDate || !bookingTime || !isDayAvailable(bookingDate, activeDoctor)}
                      className={`w-full text-center py-3 rounded-xl text-xs font-semibold uppercase tracking-wider font-sans transition-all cursor-pointer shadow-xs ${
                        (!bookingDate || !bookingTime || !isDayAvailable(bookingDate, activeDoctor))
                          ? 'bg-slate-100 text-slate-405 cursor-not-allowed'
                          : 'bg-emerald-500 hover:bg-emerald-600 text-white hover:-translate-y-0.5'
                      }`}
                      id="book-slot-primary-btn"
                    >
                      Book Consultation
                    </button>

                  </div>
                )}

                {bookingStep === 'payment' && (
                  <div className="space-y-4" id="booking-step-payment">
                    
                    <div className="text-center space-y-1 border-b border-slate-100 pb-3">
                      <div className="h-9 w-9 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center mx-auto">
                        <ShieldCheck className="w-5 h-5 text-emerald-500" />
                      </div>
                      <h3 className="font-sans font-extrabold text-sm text-slate-900">CareSync Checkout Gateway</h3>
                      <p className="text-[10px] text-slate-400">Transaction ID pending simulation approval</p>
                    </div>

                    {!paymentSuccess ? (
                      <div className="space-y-4">
                        
                        {/* Transaction Receipt */}
                        <div className="p-3 bg-slate-50 rounded-xl space-y-2 border border-slate-100 text-xs font-sans">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Appointment Code</span>
                            <span className="font-mono text-slate-900 font-medium p-0.5 bg-slate-150 rounded">{createdAppointmentId}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Consultant</span>
                            <span className="text-slate-900 font-medium">{activeDoctor.name}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Date & Slot</span>
                            <span className="text-slate-900 font-medium font-mono">{bookingDate} @ {bookingTime}</span>
                          </div>
                          <hr className="border-slate-200" />
                          <div className="flex justify-between text-sm">
                            <span className="font-bold text-slate-900">Triage Service Fee</span>
                            <span className="font-black text-emerald-600 font-mono">${activeDoctor.fees}</span>
                          </div>
                        </div>

                        {/* Card simulation credentials statement */}
                        <div className="p-2.5 bg-amber-50 border border-amber-150 rounded-xl text-[10px] font-sans text-amber-800 leading-relaxed">
                          🧑‍⚕️ <strong>Simulation Check:</strong> Click the secure Pay checkout trigger below to simulate instant Razorpay/Stripe billing capture. No real funds are demanded.
                        </div>

                        <button
                          onClick={handleProcessPayment}
                          disabled={paymentLoading}
                          className="w-full bg-slate-950 hover:bg-slate-900 text-white font-sans text-xs font-bold uppercase tracking-wider py-3.5 rounded-xl transition-all cursor-pointer shadow-xs relative flex items-center justify-center gap-1.5"
                          id="submit-payment-simulation"
                        >
                          {paymentLoading ? (
                            <>
                              <span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              <span>Capturing Token...</span>
                            </>
                          ) : (
                            <>
                              <span>Process Safe Payment (${activeDoctor.fees})</span>
                            </>
                          )}
                        </button>

                      </div>
                    ) : (
                      <div className="text-center space-y-4 py-3" id="payment-success-screen">
                        
                        <div className="mx-auto w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center animate-bounce">
                          <ShieldCheck className="w-6 h-6 text-emerald-600" />
                        </div>

                        <div className="space-y-1">
                          <h4 className="font-sans font-bold text-sm text-slate-900">Booking Verified & Paid!</h4>
                          <p className="text-[10px] text-slate-500 font-sans">Your appointment key was archived safely in hospital databases.</p>
                        </div>

                        <div className="flex flex-col gap-2 pt-2">
                          <button
                            onClick={() => setView('my-appointments')}
                            className="bg-emerald-500 hover:bg-emerald-600 text-white py-2.5 text-xs font-semibold rounded-xl transition-all cursor-pointer shadow-xs"
                            id="view-my-appt-success"
                          >
                            Go to My Appointments
                          </button>
                          <button
                            onClick={handleClearDoctorSelection}
                            className="text-slate-500 hover:text-slate-800 py-1.5 text-xs font-medium cursor-pointer"
                          >
                            Return to Directory
                          </button>
                        </div>

                      </div>
                    )}

                  </div>
                )}

              </div>

            </div>

          </div>
        ) : (
          /* ---------------- B) DOCTORS MAIN DIRECTORY LISTINGS ---------------- */
          <div className="space-y-8" id="home-doctors-listings">
            
            {/* Header intro */}
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <span className="text-[10px] font-mono tracking-widest text-[#10b981] font-bold uppercase">Clinical Directory</span>
              <h1 className="font-sans font-extrabold text-3xl text-slate-900 tracking-tight leading-none">Find Your Ideal Medical Specialist</h1>
              <p className="text-slate-500 text-xs sm:text-sm font-sans">
                Browse our real-time medical group. Filter doctors by distinct professional specializations, or query names directly.
              </p>
            </div>

            {/* Filter controls panel */}
            <div className="bg-white border border-slate-100 shadow-xs rounded-2xl p-4 sm:p-5 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              
              {/* Search text input */}
              <div className="md:col-span-4 relative">
                <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="text"
                  placeholder="Query doctor, degree, specialty..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-slate-50/60 border border-slate-100 hover:border-slate-200 focus:border-emerald-300 py-2.5 pl-10 pr-4 rounded-xl text-xs font-sans text-slate-700 outline-hidden"
                  id="doctor-search-input"
                />
              </div>

              {/* Specialty quick tabs */}
              <div className="md:col-span-8 flex flex-wrap gap-1.5 items-center">
                <span className="hidden lg:inline-block text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest mr-2">Specialty:</span>
                <button
                  onClick={() => setSelectedSpecialty('')}
                  className={`px-3 py-1.5 rounded-full text-xs font-sans font-semibold border cursor-pointer ${
                    selectedSpecialty === '' 
                      ? 'bg-slate-900 border-slate-900 text-white shadow-xs' 
                      : 'bg-slate-50 border-slate-100 text-slate-650 hover:bg-slate-100'
                  }`}
                  id="specialty-filter-all"
                >
                  All Specialties
                </button>
                {specialties.map((spec) => (
                  <button
                    key={spec}
                    onClick={() => setSelectedSpecialty(spec)}
                    className={`px-3 py-1.5 rounded-full text-xs font-sans font-semibold border cursor-pointer ${
                      selectedSpecialty === spec 
                        ? 'bg-emerald-500 border-emerald-500 text-white shadow-xs' 
                        : 'bg-slate-50 border-slate-100 text-slate-650 hover:bg-slate-100'
                    }`}
                    id={`specialty-filter-${spec.toLowerCase().replace(' ', '-')}`}
                  >
                    {spec}
                  </button>
                ))}
              </div>

            </div>

            {/* Doctors Grid output info */}
            {filteredDoctors.length === 0 ? (
              <div className="bg-white border border-slate-150 p-12 rounded-3xl text-center space-y-2">
                <p className="text-slate-400 text-xs font-sans italic">No clinical practitioners could be matched for the given queries & filters.</p>
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setSelectedSpecialty('');
                  }}
                  className="text-xs font-sans font-bold text-emerald-600 underline cursor-pointer"
                >
                  Reset directory filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredDoctors.map((doc) => (
                  <div
                    key={doc.id}
                    className="bg-white border border-slate-100 rounded-2xl p-5 hover:border-slate-200 hover:shadow-xs transition-all flex flex-col justify-between space-y-4"
                    id={`directory-card-${doc.id}`}
                  >
                    <div className="space-y-4">
                      
                      {/* Doctor avatar details block */}
                      <div className="flex gap-4 items-start">
                        <div className="w-14 h-14 rounded-xl bg-linear-to-tr from-emerald-100 to-teal-50 text-emerald-600 flex items-center justify-center font-sans font-bold text-lg shrink-0 border border-emerald-50">
                          {doc.name.split(' ').slice(1).map(n => n[0]).join('') || 'MD'}
                        </div>
                        <div className="space-y-1">
                          <h3 className="font-sans font-bold text-sm text-slate-900 leading-tight">{doc.name}</h3>
                          <p className="text-[10px] font-mono font-bold text-emerald-600 tracking-wider uppercase">{doc.specialization}</p>
                          <p className="text-[11px] text-slate-400 font-sans leading-none">{doc.qualification}</p>
                        </div>
                      </div>

                      {/* Doctor biography text */}
                      <p className="font-sans text-xs text-slate-500 leading-relaxed line-clamp-3">
                        {doc.about}
                      </p>

                      {/* Clinic operational attributes checklist */}
                      <div className="grid grid-cols-2 gap-2 border-t border-slate-50 pt-3 text-[11px] text-slate-500 font-sans">
                        <div className="flex items-center gap-1">
                          <Award className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          <span>{doc.experience} Years Exp</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          <span>Fee: ${doc.fees}</span>
                        </div>
                      </div>

                    </div>

                    <div className="pt-3 border-t border-slate-50/80 flex items-center justify-between">
                      <span className="text-[10px] text-emerald-600 font-mono font-semibold bg-emerald-50 py-0.5 px-2 rounded-md">
                        Available Weekly
                      </span>
                      <button
                        onClick={() => handleSelectDoctor(doc.id)}
                        className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold cursor-pointer transition-colors"
                        id={`schedule-btn-${doc.id}`}
                      >
                        Book Appointment
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
export default DoctorsView;
