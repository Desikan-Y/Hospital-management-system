import React from 'react';
import { useApp } from './AppContext';
import { Phone, Mail, MapPin, Heart, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setView } = useApp();

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800" id="app-footer">
      
      {/* Top Footer Sections */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Box 1: Branding */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-emerald-500 text-white p-1.5 rounded-lg">
                <Heart className="w-4 h-4 fill-white" />
              </div>
              <span className="font-sans font-bold text-lg text-white tracking-tight">CareSync</span>
            </div>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              Simplifying healthcare bookings through patient-centric digital coordination. Seamlessly matching patients with leading clinic professionals.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono tracking-wide">
              <ShieldCheck className="w-4 h-4" />
              HIPAA Compliant System
            </div>
          </div>

          {/* Box 2: Specialties Quick Link */}
          <div className="space-y-4">
            <h4 className="font-sans font-semibold text-sm text-white tracking-wide uppercase">Core Care Services</h4>
            <ul className="space-y-1.5 font-sans text-xs text-slate-400">
              <li className="hover:text-emerald-400 transition-colors cursor-pointer" onClick={() => setView('doctors')}>Cardiovascular Consults</li>
              <li className="hover:text-emerald-400 transition-colors cursor-pointer" onClick={() => setView('doctors')}>Pediatrics & Growth</li>
              <li className="hover:text-emerald-400 transition-colors cursor-pointer" onClick={() => setView('doctors')}>Neuromuscular Treatment</li>
              <li className="hover:text-emerald-400 transition-colors cursor-pointer" onClick={() => setView('doctors')}>Dental Care & Orthodontics</li>
              <li className="hover:text-emerald-400 transition-colors cursor-pointer" onClick={() => setView('doctors')}>Dermatological Screenings</li>
            </ul>
          </div>

          {/* Box 3: Quick Navigation */}
          <div className="space-y-4">
            <h4 className="font-sans font-semibold text-sm text-white tracking-wide uppercase">Hospital Links</h4>
            <div className="grid grid-cols-2 gap-2 text-xs font-sans text-slate-400">
              <button onClick={() => setView('home')} className="hover:text-emerald-400 text-left transition-colors cursor-pointer">Home</button>
              <button onClick={() => setView('doctors')} className="hover:text-emerald-400 text-left transition-colors cursor-pointer">Doctors</button>
              <button onClick={() => setView('about')} className="hover:text-emerald-400 text-left transition-colors cursor-pointer">About Us</button>
              <button onClick={() => setView('contact')} className="hover:text-emerald-400 text-left transition-colors cursor-pointer">Contact</button>
              <button onClick={() => setView('login')} className="hover:text-emerald-400 text-left transition-colors cursor-pointer">Staff Login</button>
            </div>
          </div>

          {/* Box 4: Direct Help */}
          <div className="space-y-4">
            <h4 className="font-sans font-semibold text-sm text-white tracking-wide uppercase">Headquarters</h4>
            <ul className="space-y-3 text-xs text-slate-400 font-sans">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>100 Medical Plaza, Suite 400<br />Boston, MA 02116</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>+1 (555) 390-4820</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>support@caresyncclinics.com</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Dividerline */}
        <hr className="border-slate-800 my-8" />

        {/* Bottom Rights */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 font-sans">
          <div>
            &copy; {new Date().getFullYear()} CareSync Medical Group. All rights reserved. Registered Hospital System.
          </div>
          <div className="flex gap-4">
            <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
            <span className="hover:text-slate-400 cursor-pointer">Privacy Charter</span>
            <span className="hover:text-slate-400 cursor-pointer">Patient Rights</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
export default Footer;
