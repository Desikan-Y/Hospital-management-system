import React, { useState } from 'react';
import { useApp } from './AppContext';
import { Menu, X, Calendar, User as UserIcon, LogOut, ShieldAlert, HeartPulse } from 'lucide-react';

export const Header: React.FC = () => {
  const { user, logout, activeView, setView } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (view: string) => {
    setView(view);
    setMobileMenuOpen(false);
  };

  const getDashboardLabel = () => {
    if (!user) return 'Login';
    if (user.role === 'admin') return 'Admin Panel';
    if (user.role === 'doctor') return 'Doctor Portal';
    return 'My Dashboard';
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-slate-100/90 backdrop-blur-md/85 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          
          {/* Logo / Branding */}
          <div 
            onClick={() => handleNav('home')} 
            className="flex items-center gap-2.5 cursor-pointer group"
            id="nav-logo"
          >
            <div className="bg-emerald-500 text-white p-2 rounded-xl group-hover:bg-emerald-600 transition-colors shadow-xs">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div>
              <span className="font-sans font-bold text-lg text-slate-900 tracking-tight">CareSync</span>
              <span className="block text-[10px] font-mono tracking-widest text-[#10b981] uppercase font-semibold leading-none">Clinics</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <button
              onClick={() => handleNav('home')}
              className={`font-sans text-sm font-medium transition-colors cursor-pointer px-1 py-1.5 ${
                activeView === 'home' ? 'text-emerald-600 border-b-2 border-emerald-500' : 'text-slate-600 hover:text-slate-900'
              }`}
              id="nav-btn-home"
            >
              Home
            </button>
            <button
              onClick={() => handleNav('doctors')}
              className={`font-sans text-sm font-medium transition-colors cursor-pointer px-1 py-1.5 ${
                activeView === 'doctors' || activeView.startsWith('doctor/') ? 'text-emerald-600 border-b-2 border-emerald-500' : 'text-slate-600 hover:text-slate-900'
              }`}
              id="nav-btn-doctors"
            >
              Find Doctors
            </button>
            <button
              onClick={() => handleNav('about')}
              className={`font-sans text-sm font-medium transition-colors cursor-pointer px-1 py-1.5 ${
                activeView === 'about' ? 'text-emerald-600 border-b-2 border-emerald-500' : 'text-slate-600 hover:text-slate-900'
              }`}
              id="nav-btn-about"
            >
              About
            </button>
            <button
              onClick={() => handleNav('contact')}
              className={`font-sans text-sm font-medium transition-colors cursor-pointer px-1 py-1.5 ${
                activeView === 'contact' ? 'text-emerald-600 border-b-2 border-emerald-500' : 'text-slate-600 hover:text-slate-900'
              }`}
              id="nav-btn-contact"
            >
              Contact
            </button>
          </nav>

          {/* User Auth Controls */}
          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-3">
                
                {/* Specific features based on user type */}
                {user.role === 'patient' && (
                  <button
                    onClick={() => handleNav('my-appointments')}
                    className="flex items-center gap-1.5 text-xs font-sans font-medium text-slate-700 bg-slate-50 border border-slate-200/80 px-3 py-1.5 rounded-lg hover:bg-slate-100 transition-all cursor-pointer"
                    id="nav-btn-my-appt"
                  >
                    <Calendar className="w-3.5 h-3.5 text-emerald-500" />
                    My Bookings
                  </button>
                )}

                <button
                  onClick={() => handleNav(user.role === 'patient' ? 'dashboard' : 'dashboard')}
                  className="flex items-center gap-1.5 text-xs font-sans font-semibold text-white bg-slate-900 hover:bg-slate-850 px-3.5 py-1.5 rounded-xl transition-all shadow-xs cursor-pointer"
                  id="nav-btn-dashboard"
                >
                  {user.role === 'admin' ? (
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                  ) : (
                    <UserIcon className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                  {getDashboardLabel()}
                </button>

                <button
                  onClick={logout}
                  className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-all cursor-pointer"
                  title="Sign out of hospital account"
                  id="nav-btn-logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleNav('register')}
                  className="text-xs font-sans font-medium text-slate-700 hover:text-slate-900 px-3 py-1.5 rounded-lg cursor-pointer transition-colors"
                  id="nav-btn-reg-patient"
                >
                  Register
                </button>
                <div className="h-4 w-[1px] bg-slate-200" />
                <button
                  onClick={() => handleNav('login')}
                  className="text-xs font-sans font-semibold text-white bg-emerald-500 hover:bg-emerald-600 px-4 py-2 rounded-xl transition-all shadow-xs shadow-emerald-500/10 cursor-pointer"
                  id="nav-btn-login-gateway"
                >
                  Sign In
                </button>
              </div>
            )}
          </div>

          {/* Mobile hamburger menu toggle */}
          <div className="md:hidden flex items-center gap-2">
            {user && (
              <span className="text-xs font-sans font-medium text-slate-500 mr-1 bg-slate-50 border border-slate-100 px-2 py-1 rounded-md">
                {user.role === 'admin' ? 'Admin' : user.role === 'doctor' ? 'MD' : 'Patient'}
              </span>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 rounded-lg outline-hidden cursor-pointer"
              id="nav-btn-toggle-mobile"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-150 py-3 px-4 flex flex-col gap-2.5 animate-fadeIn">
          <button
            onClick={() => handleNav('home')}
            className={`text-left font-sans text-sm font-medium p-2.5 rounded-lg ${
              activeView === 'home' ? 'bg-emerald-50 text-emerald-600' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNav('doctors')}
            className={`text-left font-sans text-sm font-medium p-2.5 rounded-lg ${
              activeView === 'doctors' ? 'bg-emerald-50 text-emerald-600' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            Find Doctors
          </button>
          <button
            onClick={() => handleNav('about')}
            className={`text-left font-sans text-sm font-medium p-2.5 rounded-lg ${
              activeView === 'about' ? 'bg-emerald-50 text-emerald-600' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            About
          </button>
          <button
            onClick={() => handleNav('contact')}
            className={`text-left font-sans text-sm font-medium p-2.5 rounded-lg ${
              activeView === 'contact' ? 'bg-emerald-50 text-emerald-600' : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            Contact
          </button>

          <hr className="border-slate-100 my-1" />

          {user ? (
            <div className="flex flex-col gap-2 pt-1">
              {user.role === 'patient' && (
                <button
                  onClick={() => handleNav('my-appointments')}
                  className="flex items-center gap-2 text-left font-sans text-sm font-medium p-2.5 hover:bg-slate-50 text-slate-600/90 rounded-lg"
                >
                  <Calendar className="w-4 h-4 text-emerald-500" />
                  My Bookings
                </button>
              )}
              <button
                onClick={() => handleNav('dashboard')}
                className="flex items-center gap-2 text-left font-sans text-sm font-semibold p-2.5 bg-slate-900 text-white rounded-xl shadow-xs"
              >
                <UserIcon className="w-4 h-4 text-emerald-400" />
                {getDashboardLabel()}
              </button>
              <button
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-2 text-left font-sans text-sm font-medium p-2.5 text-rose-500 hover:bg-[#fff5f5] rounded-lg mt-1"
              >
                <LogOut className="w-4 h-4 text-rose-400" />
                Sign Out
              </button>
            </div>
          ) : (
            <div className="flex gap-2.5 pt-1.5">
              <button
                onClick={() => handleNav('register')}
                className="flex-1 text-center font-sans text-sm font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 p-2.5 rounded-xl border border-slate-200"
              >
                Register
              </button>
              <button
                onClick={() => handleNav('login')}
                className="flex-1 text-center font-sans text-sm font-semibold text-white bg-emerald-500 hover:bg-emerald-600 p-2.5 rounded-xl"
              >
                Sign In
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
};
export default Header;
