import React from 'react';
import { useApp } from './AppContext';
import { HeartPulse, Star, Users, Briefcase, CalendarCheck, ArrowRight, ShieldCheck } from 'lucide-react';
import { Specialization } from '../types';

export const HomeView: React.FC = () => {
  const { doctors, setView } = useApp();

  // Display top 4 doctors
  const topDoctors = doctors.filter(d => d.approved).slice(0, 4);

  const specialties: { name: Specialization; desc: string; icon: string }[] = [
    { name: 'Cardiologist', desc: 'Heart care & valve hygiene', icon: '❤️' },
    { name: 'Dentist', desc: 'Cavity checkup & correction', icon: '🦷' },
    { name: 'Neurologist', desc: 'Brain & nerve coordination', icon: '🧠' },
    { name: 'Pediatrician', desc: 'Infant growth & immunizations', icon: '👶' },
    { name: 'Orthopedic', desc: 'Posture & bone integrity', icon: '🦴' },
    { name: 'Dermatologist', desc: 'Skin barrier & allergy control', icon: '✨' },
    { name: 'General Physician', desc: 'Family care & routine checkup', icon: '🩺' }
  ];

  const selectSpecialty = (spec: Specialization) => {
    // Navigate to Doctors with specialization filter (using localStorage or custom parameter to filter)
    localStorage.setItem('selected_specialty_filter', spec);
    setView('doctors');
  };

  return (
    <div className="space-y-16 pb-16 bg-slate-50/50" id="home-view-page">
      
      {/* 1. HERO SECTION */}
      <section className="relative px-4 sm:px-6 lg:px-8 pt-8 pb-12 sm:pb-16 bg-linear-to-b from-emerald-50/70 to-transparent">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white border border-slate-100 rounded-full shadow-xs">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[11px] font-mono font-bold text-slate-700 tracking-wider uppercase">CareSync Hospital Group</span>
            </div>

            <h1 className="font-sans font-extrabold text-3xl sm:text-5xl text-slate-900 tracking-tight leading-tight">
              Schedule Your Next <span className="text-emerald-600">Doctor Visit</span> Effortlessly
            </h1>

            <p className="font-sans text-sm sm:text-base text-slate-500 leading-relaxed max-w-xl">
              Access trusted board-certified health professionals, compare real-world availabilities, and lock in consultations in under sixty seconds. Safe, HIPAA-compliant patient management.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={() => setView('doctors')}
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-sans font-semibold text-sm transition-all shadow-md shadow-emerald-500/15 cursor-pointer hover:-translate-y-0.5"
                id="hero-book-btn"
              >
                <span>Find & Book Doctor</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => setView('about')}
                className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 font-sans font-medium text-sm transition-all cursor-pointer"
                id="hero-about-btn"
              >
                Our Clinical Mission
              </button>
            </div>

            {/* Micro Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-100 max-w-lg">
              <div>
                <span className="block font-sans font-black text-lg md:text-xl text-slate-900">40+</span>
                <span className="block text-[11px] font-sans text-slate-400">Core Doctors</span>
              </div>
              <div>
                <span className="block font-sans font-black text-lg md:text-xl text-slate-900">12,000+</span>
                <span className="block text-[11px] font-sans text-slate-400">Happy Patients</span>
              </div>
              <div>
                <span className="block font-sans font-black text-lg md:text-xl text-slate-900">99.4%</span>
                <span className="block text-[11px] font-sans text-slate-400">Fulfillment</span>
              </div>
            </div>

          </div>

          <div className="lg:col-span-5 relative">
            <div className="absolute inset-0 bg-emerald-100 rounded-3xl blur-3xl opacity-30 -z-10" />
            <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm space-y-6">
              
              <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
                <div className="p-2.5 bg-emerald-50 rounded-xl">
                  <CalendarCheck className="w-5 h-5 text-emerald-500" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-sm text-slate-900">Immediate Slot Triage</h4>
                  <p className="text-[11px] text-slate-400">Find the closest matching expert</p>
                </div>
              </div>

              {/* Simulated Search Form Widget */}
              <div className="space-y-3.5">
                <div>
                  <label className="block text-[10px] font-mono tracking-wider text-slate-400 uppercase font-bold mb-1.5">Consultation Need</label>
                  <select 
                    className="w-full bg-slate-50 border border-slate-100 px-3 py-2.5 rounded-xl font-sans text-xs text-slate-700 outline-hidden focus:border-emerald-300"
                    onChange={(e) => {
                      if (e.target.value) selectSpecialty(e.target.value as Specialization);
                    }}
                    id="hero-specialty-selectbox"
                  >
                    <option value="">Select Specialty...</option>
                    {specialties.map(s => (
                      <option key={s.name} value={s.name}>{s.name}</option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={() => setView('doctors')}
                  className="w-full text-center bg-slate-900 hover:bg-slate-850 text-white font-sans text-xs font-semibold py-3 rounded-xl transition-all cursor-pointer shadow-xs"
                  id="hero-search-quick"
                >
                  Browse Available Schedules
                </button>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-[10px] font-mono text-slate-400 bg-slate-50 p-2 rounded-lg">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                No credit card required to explore
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* 2. SPECIALTY SEARCH GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center space-y-2">
          <span className="text-[10px] font-mono tracking-widest text-emerald-500 font-bold uppercase">
            Specialized Medicine
          </span>
          <h2 className="font-sans font-bold text-2xl sm:text-3xl text-slate-900 tracking-tight">
            Find Doctors by Health Speciality
          </h2>
          <p className="font-sans text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
            Choose a focused division branch below to instantly view custom practitioners currently accepting appointments.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-4">
          {specialties.map((spec) => (
            <div
              key={spec.name}
              onClick={() => selectSpecialty(spec.name)}
              className="bg-white border border-slate-100 hover:border-emerald-200/60 p-4 rounded-2xl flex flex-col items-center text-center gap-2.5 transition-all cursor-pointer hover:shadow-xs group hover:-translate-y-0.5"
              id={`spec-card-${spec.name.toLowerCase().replace(' ', '-')}`}
            >
              <span className="text-2xl mb-1 filter drop-shadow-xs group-hover:scale-110 transition-transform">{spec.icon}</span>
              <div>
                <h3 className="font-sans font-bold text-xs text-slate-900 group-hover:text-emerald-600 transition-colors">{spec.name}</h3>
                <p className="text-[9px] text-slate-400 font-sans mt-0.5 line-clamp-2 leading-tight">{spec.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. SHOWCASE / TOP DOCTORS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono tracking-widest text-[#10b981] font-bold uppercase">Clinical Registry</span>
            <h2 className="font-sans font-bold text-2xl text-slate-900 tracking-tight">Top Rated Clinical Pioneers</h2>
            <p className="font-sans text-xs text-slate-500">Board-certified medical specialists currently scheduling online consults.</p>
          </div>
          <button
            onClick={() => {
              localStorage.removeItem('selected_specialty_filter');
              setView('doctors');
            }}
            className="flex items-center gap-1 text-xs font-sans font-semibold text-emerald-600 hover:text-emerald-700 transition-colors pb-1 border-b border-transparent hover:border-emerald-500 cursor-pointer w-fit"
            id="view-all-docs-home"
          >
            <span>View All Doctors ({doctors.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {topDoctors.length === 0 ? (
          <div className="bg-white border border-slate-100 p-8 rounded-2xl text-center text-slate-400 text-xs">
            No approved medical professionals have registered yet under hospital directories.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {topDoctors.map((doc) => (
              <div
                key={doc.id}
                className="bg-white border border-slate-100 rounded-2xl overflow-hidden hover:border-slate-200 transition-all shadow-xs flex flex-col"
                id={`doc-card-${doc.id}`}
              >
                {/* Doctor Avatar / Thumbnail Background */}
                <div className="aspect-square bg-slate-50 border-b border-slate-100 flex items-center justify-center p-8 relative">
                  <div className="absolute top-3 left-3 bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase flex items-center gap-1 border border-emerald-100">
                    <span className="h-1 w-1 bg-emerald-500 rounded-full animate-ping" />
                    Available
                  </div>
                  
                  {/* Big initials avatar */}
                  <div className="w-20 h-20 rounded-full bg-linear-to-tr from-emerald-100 to-teal-50 text-emerald-600 flex items-center justify-center font-sans font-bold text-2xl shadow-xs border border-white">
                    {doc.name.split(' ').slice(1).map(n => n[0]).join('') || 'MD'}
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-[10px] font-sans font-medium text-slate-400">
                      <span>{doc.specialization}</span>
                      <span>•</span>
                      <span>{doc.experience} Yrs Exp</span>
                    </div>
                    <h3 className="font-sans font-bold text-sm text-slate-900 line-clamp-1">{doc.name}</h3>
                    <p className="text-[11px] text-slate-400 font-mono line-clamp-1">{doc.qualification}</p>
                    <p className="text-slate-500 text-[11px] leading-relaxed line-clamp-2">{doc.about}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-50 flex items-center justify-between text-xs font-sans">
                    <div>
                      <span className="block text-[9px] text-slate-400 font-mono">CONSULTATION FEE</span>
                      <span className="text-slate-900 font-bold font-mono">${doc.fees}</span>
                    </div>
                    <button
                      onClick={() => setView('doctors', doc.id)}
                      className="px-3.5 py-1.5 bg-emerald-50 text-emerald-600 hover:bg-emerald-500 hover:text-white rounded-xl text-xs font-semibold cursor-pointer transition-all"
                      id={`book-doc-btn-${doc.id}`}
                    >
                      Book Appointment
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 4. SEAMLESS WORKFLOW STEPS */}
      <section className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-2">
            <span className="text-[10px] font-mono tracking-widest text-[#10b981] font-bold uppercase col-span-3">Digitized Flow</span>
            <h2 className="font-sans font-bold text-2xl tracking-tight text-white">How Clinical Scheduling Works</h2>
            <p className="font-sans text-xs text-slate-400 max-w-sm mx-auto">Three simplified points to take care of you and your loved ones.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            <div className="space-y-2 text-center md:text-left">
              <div className="w-10 h-10 bg-slate-800 text-emerald-450 border border-slate-750 font-bold font-mono text-sm rounded-xl flex items-center justify-center mx-auto md:mx-0">
                01
              </div>
              <h3 className="font-sans font-extrabold text-sm text-white">Filter Specialty & Doctor</h3>
              <p className="font-sans text-xs text-slate-400 leading-relaxed">
                Browse our secure portal. Filter practitioners based on specialized medical branches, consult fees, clinic availability, or qualification backgrounds.
              </p>
            </div>

            <div className="space-y-2 text-center md:text-left">
              <div className="w-10 h-10 bg-slate-800 text-emerald-450 border border-slate-750 font-bold font-mono text-sm rounded-xl flex items-center justify-center mx-auto md:mx-0">
                02
              </div>
              <h3 className="font-sans font-extrabold text-sm text-white">Select Timings & Dates</h3>
              <p className="font-sans text-xs text-slate-400 leading-relaxed">
                View real-time doctor availability calendars. Pick local dates and time intervals that fit comfortably into your routine schedule.
              </p>
            </div>

            <div className="space-y-2 text-center md:text-left">
              <div className="w-10 h-10 bg-slate-800 text-emerald-450 border border-slate-750 font-bold font-mono text-sm rounded-xl flex items-center justify-center mx-auto md:mx-0">
                03
              </div>
              <h3 className="font-sans font-extrabold text-sm text-white">Checkout Securely</h3>
              <p className="font-sans text-xs text-slate-400 leading-relaxed">
                Establish a quick record, complete payment simulation safely via Razorpay template routines, and download instant print-ready summary confirmations.
              </p>
            </div>

          </div>

        </div>
      </section>

    </div>
  );
};
export default HomeView;
