import React, { useState } from 'react';
import { useApp } from './AppContext';
import { User, ShieldAlert, KeyRound, Mail, UserPlus, LogIn, ChevronRight } from 'lucide-react';

export const LoginView: React.FC = () => {
  const { login, registerPatient, error, setError } = useApp();
  
  // Outer mode: login vs register
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  
  // Login fields
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<'patient' | 'doctor' | 'admin'>('patient');

  // Registration fields (for new patient)
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regGender, setRegGender] = useState('Male');
  const [regAge, setRegAge] = useState<number>(25);

  const [formLoading, setFormLoading] = useState(false);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      setError("Please input your diagnostic email and password credentials.");
      return;
    }
    setFormLoading(true);
    const success = await login(loginEmail, loginPassword, selectedRole);
    setFormLoading(false);
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail || !regPassword) {
      setError("Required fields: Full Name, Email, Password.");
      return;
    }
    setFormLoading(true);
    const success = await registerPatient({
      name: regName,
      email: regEmail,
      password: regPassword,
      phone: regPhone,
      gender: regGender,
      age: regAge
    });
    setFormLoading(false);
  };

  // Pre-fill demo simulations!
  const triggerSimulation = (role: 'patient' | 'doctor' | 'admin') => {
    setAuthMode('login');
    setSelectedRole(role);
    setError(null);
    if (role === 'admin') {
      setLoginEmail('admin@health.com');
      setLoginPassword('admin123');
    } else if (role === 'doctor') {
      setLoginEmail('richard@health.com'); // Dr Jenkins
      setLoginPassword('doctor123');
    } else {
      setLoginEmail('john@demo.com');
      setLoginPassword('patient123');
    }
  };

  return (
    <div className="py-12 bg-slate-50 min-h-screen flex items-center justify-center font-sans px-4 sm:px-6 lg:px-8" id="unified-login-page">
      <div className="w-full max-w-md space-y-6">

        {/* Brand & Triage Banner */}
        <div className="text-center space-y-1">
          <span className="text-[10px] font-mono tracking-widest text-[#10b981] font-bold uppercase py-0.5 px-2 bg-emerald-100/60 rounded-full border border-emerald-50 w-fit mx-auto">
            HOSPITAL PORTAL LOCK
          </span>
          <h1 className="font-sans font-black text-2xl text-slate-900 tracking-tight mt-1">
            CareSync Clinic Sign-In
          </h1>
          <p className="text-slate-500 text-xs">
            {authMode === 'login' ? 'Validate your credentials or select staff channels.' : 'Establish a formal clinic patient health directory.'}
          </p>
        </div>

        {/* Demo Fast Sandbox Triage Simulations (Highly Helpful!) */}
        <div className="bg-white border border-slate-150 p-4 rounded-2xl shadow-xs space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider">Fast Sandbox Simulations</span>
            <span className="text-[9px] font-sans text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-md font-semibold">Ready</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => triggerSimulation('patient')}
              className="py-1.5 px-2.5 bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200 text-[10px] font-bold rounded-lg cursor-pointer text-center"
              id="simulate-patient-login-btn"
            >
              👤 Patient Doe
            </button>
            <button
              onClick={() => triggerSimulation('doctor')}
              className="py-1.5 px-2.5 bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200 text-[10px] font-bold rounded-lg cursor-pointer text-center"
              id="simulate-doctor-login-btn"
            >
              🩺 Dr. Jenkins
            </button>
            <button
              onClick={() => triggerSimulation('admin')}
              className="py-1.5 px-2.5 bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200 text-[10px] font-bold rounded-lg cursor-pointer text-center"
              id="simulate-admin-login-btn"
            >
              👑 Admin Staff
            </button>
          </div>
        </div>

        {/* Main interactive validation wrapper */}
        <div className="bg-white border border-slate-100 shadow-sm rounded-3xl overflow-hidden">
          
          {/* Main Tab bar navigation */}
          <div className="flex bg-slate-50 border-b border-slate-100 p-1">
            <button
              onClick={() => {
                setAuthMode('login');
                setError(null);
              }}
              className={`flex-1 py-2 text-center text-xs font-bold font-sans rounded-xl transition-all cursor-pointer ${
                authMode === 'login' 
                  ? 'bg-white text-slate-900 shadow-xs' 
                  : 'text-slate-400 hover:text-slate-700'
              }`}
            >
              Account Login
            </button>
            <button
              onClick={() => {
                setAuthMode('register');
                setError(null);
              }}
              className={`flex-1 py-2 text-center text-xs font-bold font-sans rounded-xl transition-all cursor-pointer ${
                authMode === 'register' 
                  ? 'bg-white text-slate-900 shadow-xs' 
                  : 'text-slate-400 hover:text-slate-700'
              }`}
            >
              Patient Sign-Up
            </button>
          </div>

          <div className="p-6 sm:p-8">
            
            {/* Context Error Alert wrapper */}
            {error && (
              <div className="mb-5 p-3 rounded-xl bg-rose-50 border border-rose-150 text-rose-850 text-xs font-sans flex items-start gap-2 animate-fadeIn" id="auth-error-banner">
                <ShieldAlert className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                <span className="leading-tight">{error}</span>
              </div>
            )}

            {/* ---------------- A) LOGIN CHANNEL FORM ---------------- */}
            {authMode === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4" id="hospital-login-form">
                
                {/* Role select picker tabs */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">
                    Staff & Patient Roles
                  </label>
                  <div className="grid grid-cols-3 gap-1.5 bg-slate-50 p-1 rounded-xl border border-slate-100">
                    {(['patient', 'doctor', 'admin'] as const).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setSelectedRole(r)}
                        className={`py-1.5 text-center text-[10px] font-extrabold uppercase font-sans rounded-lg transition-all cursor-pointer ${
                          selectedRole === r 
                            ? 'bg-emerald-500 text-white shadow-xs' 
                            : 'text-slate-505 hover:text-slate-800'
                        }`}
                        id={`role-tab-${r}`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400 shrink-0" />
                    <input
                      type="email"
                      required
                      placeholder="e.g., john@demo.com"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="w-full bg-slate-50/50 border border-slate-100 focus:border-emerald-300 pl-10 pr-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                      id="login-email-input"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Password Secret</label>
                  <div className="relative">
                    <KeyRound className="absolute left-3 top-2.5 w-4 h-4 text-slate-400 shrink-0" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full bg-slate-50/50 border border-slate-100 focus:border-emerald-300 pl-10 pr-3.5 py-2.5 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                      id="login-password-input"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={formLoading}
                  className="w-full bg-slate-900 hover:bg-slate-850 text-white font-sans text-xs font-semibold py-3 rounded-xl transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1 mt-6"
                  id="submit-login-primary"
                >
                  <LogIn className="w-3.5 h-3.5 text-emerald-450" />
                  <span>{formLoading ? 'Verifying...' : `Access ${selectedRole} Account`}</span>
                </button>

              </form>
            )}

            {/* ---------------- B) PATIENT REGISTRATION FORM ---------------- */}
            {authMode === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5" id="patient-registration-form">
                
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Full Name <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Jane Doe"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full bg-slate-50/50 border border-slate-100 focus:border-emerald-305 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="register-name-input"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Email Address <span className="text-rose-500">*</span></label>
                  <input
                    type="email"
                    required
                    placeholder="e.g., jane@demo.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-slate-50/50 border border-slate-100 focus:border-emerald-305 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="register-email-input"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Secure Password <span className="text-rose-500">*</span></label>
                  <input
                    type="password"
                    required
                    placeholder="Minimal 6 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full bg-slate-50/50 border border-slate-100 focus:border-emerald-305 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="register-password-input"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Biological Sex</label>
                    <select
                      value={regGender}
                      onChange={(e) => setRegGender(e.target.value)}
                      className="w-full bg-slate-50/50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                      id="register-gender-selector"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Non-Binary">Non-Binary</option>
                      <option value="Not Specified">Prefer Not To State</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Age (Years)</label>
                    <input
                      type="number"
                      min={1}
                      max={120}
                      value={regAge}
                      onChange={(e) => setRegAge(Number(e.target.value))}
                      className="w-full bg-slate-50/50 border border-slate-100 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                      id="register-age-input"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Phone number</label>
                  <input
                    type="tel"
                    placeholder="e.g., 555-019-2831"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full bg-slate-50/50 border border-slate-101 focus:border-emerald-305 px-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="register-phone-input"
                  />
                </div>

                <button
                  type="submit"
                  disabled={formLoading}
                  className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-sans text-xs font-bold uppercase tracking-wider py-3.5 rounded-xl transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5 mt-5"
                  id="submit-register-primary"
                >
                  <UserPlus className="w-4 h-4 text-white" />
                  <span>{formLoading ? 'Creating User...' : 'Verify & Open Account'}</span>
                </button>

              </form>
            )}

          </div>
        </div>

      </div>
    </div>
  );
};
export default LoginView;
