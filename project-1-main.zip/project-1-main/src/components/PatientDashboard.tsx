import React, { useState, useEffect } from 'react';
import { useApp } from './AppContext';
import { Calendar, User, Clock, CheckCircle2, ShieldAlert, XCircle, DollarSign, Wallet, Phone, RefreshCw } from 'lucide-react';
import { Appointment } from '../types';

export const PatientDashboard: React.FC = () => {
  const { 
    user, 
    appointments, 
    updateProfile, 
    payAppointment, 
    cancelAppointment, 
    refreshAppointments 
  } = useApp();

  // Profile fields editing
  const [profileName, setProfileName] = useState(user?.name || '');
  const [profilePhone, setProfilePhone] = useState(user?.phone || '');
  const [profileAge, setProfileAge] = useState(user?.age || 30);
  const [profileGender, setProfileGender] = useState(user?.gender || 'Male');
  
  const [editSuccess, setEditSuccess] = useState(false);
  const [editLoading, setEditLoading] = useState(false);
  const [checkoutLoadingId, setCheckoutLoadingId] = useState<string | null>(null);

  // Appointments category tab state
  const [selectedTab, setSelectedTab] = useState<'all' | 'upcoming' | 'past'>('all');

  useEffect(() => {
    if (user) {
      setProfileName(user.name);
      setProfilePhone(user.phone || '');
      setProfileAge(user.age || 30);
      setProfileGender(user.gender || 'Male');
    }
  }, [user]);

  // Calculations for patient metrics
  const patientAppointments = appointments; 
  const totalBookings = patientAppointments.length;
  
  const upcomingBookings = patientAppointments.filter(a => a.status === 'Upcoming').length;
  
  const completedVisits = patientAppointments.filter(a => a.status === 'Completed').length;
  
  const totalHealthSpend = patientAppointments
    .filter(a => a.paymentStatus === 'Paid' && a.status !== 'Cancelled')
    .reduce((sum, a) => sum + a.fee, 0);

  // Filtered list based on tabs
  const filteredAppointments = patientAppointments.filter(a => {
    if (selectedTab === 'upcoming') {
      return a.status === 'Upcoming';
    } else if (selectedTab === 'past') {
      return a.status === 'Completed' || a.status === 'Cancelled';
    }
    return true; // value 'all'
  });

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setEditLoading(true);
    setEditSuccess(false);

    const success = await updateProfile({
      name: profileName,
      phone: profilePhone,
      age: Number(profileAge),
      gender: profileGender
    });

    setEditLoading(false);
    if (success) {
      setEditSuccess(true);
      setTimeout(() => setEditSuccess(false), 3000);
    }
  };

  const handlePay = async (apptId: string) => {
    setCheckoutLoadingId(apptId);
    // Simulate transaction processing
    setTimeout(async () => {
      await payAppointment(apptId);
      setCheckoutLoadingId(null);
    }, 1000);
  };

  const handleCancelClick = async (apptId: string) => {
    if (confirm("Are you positive you wish to cancel this scheduled clinical slot?")) {
      await cancelAppointment(apptId);
    }
  };

  if (!user) {
    return (
      <div className="p-12 text-center text-slate-400 font-sans">
        Patient authentication directories are loading...
      </div>
    );
  }

  return (
    <div className="py-10 bg-slate-50 min-h-screen font-sans" id="patient-dashboard-container">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Welcome / Intake Headline */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white border border-slate-100 p-6 rounded-3xl shadow-xs">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-[10px] font-mono tracking-widest text-emerald-500 font-bold uppercase">Patient Desk</span>
            <h1 className="font-sans font-extrabold text-2xl text-slate-900 tracking-tight leading-none">
              Welcome Back, {user.name}
            </h1>
            <p className="text-slate-405 text-xs">Manage active clinic reservations and health account settings.</p>
          </div>
          
          <button
            onClick={() => refreshAppointments()}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100/90 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-all cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            <span>Sync Records</span>
          </button>
        </div>

        {/* 1. HEALTH METRICS SECTION PROGRESS PANEL */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          
          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
              <Calendar className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">Total Booked</span>
              <span className="block text-lg font-black text-slate-900 font-mono">{totalBookings}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-sky-50 text-sky-600 rounded-xl flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5 text-sky-500" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">Upcoming Slots</span>
              <span className="block text-lg font-black text-slate-900 font-mono">{upcomingBookings}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">Completed Consults</span>
              <span className="block text-lg font-black text-slate-900 font-mono">{completedVisits}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-xs flex items-center gap-3">
            <div className="h-10 w-10 bg-rose-50 text-rose-605 rounded-xl flex items-center justify-center shrink-0">
              <Wallet className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <span className="block text-[10px] font-mono text-slate-400 uppercase">Total Spent</span>
              <span className="block text-lg font-black text-slate-900 font-mono">${totalHealthSpend}</span>
            </div>
          </div>

        </div>

        {/* 2. DUAL LAYOUT: PROFILE CONFIG & APPOINTMENTS GRID */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* PROFILE CONFIG (Left Column) */}
          <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-6">
            
            <div className="border-b border-slate-100 pb-3">
              <h3 className="font-sans font-extrabold text-sm text-slate-900">Personal Patient Directory</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">Maintain up-to-date profiling parameters</p>
            </div>

            <form onSubmit={handleProfileSave} className="space-y-4" id="patient-profile-update-form">
              
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Full Identification Name</label>
                <input
                  type="text"
                  required
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-100 focus:border-emerald-300 px-3 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                  id="patient-profile-name"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Biological Sex</label>
                  <select
                    value={profileGender}
                    onChange={(e) => setProfileGender(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 px-3 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="patient-profile-gender"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Non-Binary">Non-Binary</option>
                    <option value="Not Specified">Not Specified</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Age (Years)</label>
                  <input
                    type="number"
                    min={1}
                    max={120}
                    value={profileAge}
                    onChange={(e) => setProfileAge(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-100 px-3 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="patient-profile-age"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase font-mono tracking-wider">Patient Phone Contact</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <input
                    type="tel"
                    placeholder="e.g., 555-081-3920"
                    value={profilePhone}
                    onChange={(e) => setProfilePhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 pl-9 pr-3.5 py-2 rounded-xl text-xs font-sans text-slate-705 outline-hidden"
                    id="patient-profile-phone"
                  />
                </div>
              </div>

              {editSuccess && (
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100 text-[#10b981] font-medium text-[11px] text-center" id="profile-edit-success-alert">
                  ✓ Core physiological registry updated successfully!
                </div>
              )}

              <button
                type="submit"
                disabled={editLoading}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-sans text-xs font-semibold py-2.5 rounded-xl transition-all shadow-xs cursor-pointer text-center"
                id="save-patient-profile-btn"
              >
                {editLoading ? 'Synchronizing File...' : 'Update Health Profile'}
              </button>

            </form>

          </div>

          {/* APPOINTMENT BOOKINGS DATABASE LIST (Right Column) */}
          <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-100 shadow-xs space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-sans font-extrabold text-sm text-slate-900">Health Bookings Registry</h3>
                <p className="text-[10px] text-slate-400 mt-0.5">Review dates, times, and payment billing clearances</p>
              </div>

              {/* Filtering category tabs */}
              <div className="flex gap-1 bg-slate-50 p-1 rounded-lg border border-slate-100">
                {(['all', 'upcoming', 'past'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setSelectedTab(tab)}
                    className={`px-3 py-1 text-[10px] font-bold uppercase rounded-md transition-all cursor-pointer ${
                      selectedTab === tab
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* List entries */}
            {filteredAppointments.length === 0 ? (
              <div className="p-12 text-center border-2 border-dashed border-slate-100 rounded-2xl">
                <p className="text-slate-405 text-xs italic font-sans">No clinical booking entries catalogued for this selected filter.</p>
              </div>
            ) : (
              <div className="space-y-4" id="patient-appointments-list">
                {filteredAppointments.map((appt) => (
                  <div
                    key={appt.id}
                    className="border border-slate-100 p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-200 transition-all"
                    id={`appt-patient-item-${appt.id}`}
                  >
                    <div className="space-y-3">
                      
                      {/* Doctor branding */}
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-lg bg-linear-to-tr from-emerald-50 to-teal-10 border border-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-sm font-sans shrink-0">
                          MD
                        </div>
                        <div>
                          <h4 className="font-sans font-extrabold text-xs text-slate-900 leading-tight">{appt.doctorName}</h4>
                          <span className="text-[9px] font-mono uppercase font-bold text-emerald-600 tracking-wider">
                            {appt.doctorSpecialization}
                          </span>
                        </div>
                      </div>

                      {/* Detail nodes */}
                      <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs font-sans text-slate-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          <span className="font-mono">{appt.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          <span className="font-mono">{appt.timeSlot}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                          <span className="font-mono">Fee: ${appt.fee}</span>
                        </div>
                      </div>

                      {/* Status Badges line */}
                      <div className="flex flex-wrap items-center gap-2">
                        
                        {/* Attendance State */}
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase border ${
                          appt.status === 'Upcoming' 
                            ? 'bg-sky-50 border-sky-100 text-sky-700'
                            : appt.status === 'Completed'
                            ? 'bg-amber-50 border-amber-100 text-amber-700'
                            : 'bg-rose-50 border-rose-100 text-rose-700 line-through'
                        }`}>
                          {appt.status}
                        </span>

                        {/* Payment Billing Clearance */}
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase border ${
                          appt.paymentStatus === 'Paid'
                            ? 'bg-emerald-50 border-emerald-100 text-emerald-700'
                            : 'bg-amber-50 border-amber-100 text-amber-705'
                        }`}>
                          💳 {appt.paymentStatus}
                        </span>

                        {appt.transactionId && (
                          <span className="text-[9px] font-mono text-slate-400">
                            Txn: {appt.transactionId}
                          </span>
                        )}

                      </div>

                    </div>

                    {/* Active Action triggers (Cancellation / Invoice checkout) */}
                    {appt.status === 'Upcoming' && (
                      <div className="flex sm:flex-col gap-2 shrink-0">
                        
                        {appt.paymentStatus === 'Pending' && (
                          <button
                            onClick={() => handlePay(appt.id)}
                            disabled={checkoutLoadingId !== null}
                            className="bg-slate-900 hover:bg-slate-800 text-white font-semibold text-[11px] px-3 py-1.5 rounded-xl transition-all cursor-pointer shadow-xs whitespace-nowrap flex items-center justify-center gap-1"
                            id={`pay-appt-btn-${appt.id}`}
                          >
                            {checkoutLoadingId === appt.id ? (
                              <span className="h-3 w-3 border border-white/30 border-t-white rounded-full animate-spin" />
                            ) : 'Pay Consultation Fee'}
                          </button>
                        )}

                        <button
                          onClick={() => handleCancelClick(appt.id)}
                          className="bg-[#fff5f5] hover:bg-[#ffe3e3] border border-rose-100 text-rose-550 font-semibold text-[11px] px-3 py-1.5 rounded-xl transition-colors cursor-pointer"
                          id={`cancel-appt-btn-${appt.id}`}
                        >
                          Cancel Appointment
                        </button>

                      </div>
                    )}

                  </div>
                ))}
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
};
export default PatientDashboard;
