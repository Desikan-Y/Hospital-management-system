export type UserRole = 'patient' | 'doctor' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'patient' | 'admin';
  phone?: string;
  gender?: string;
  age?: number;
}

export type Specialization = 
  | 'Cardiologist' 
  | 'Dentist' 
  | 'Neurologist' 
  | 'Pediatrician' 
  | 'Orthopedic'
  | 'Dermatologist'
  | 'General Physician';

export interface Doctor {
  id: string;
  name: string;
  email: string;
  role: 'doctor';
  specialization: Specialization;
  qualification: string;
  experience: number;
  fees: number;
  about: string;
  availability: string[]; // e.g., ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
  timings: string[]; // e.g. ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM"]
  approved: boolean;
  image: string; // SVG path or short visual identifier
}

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientAge: number;
  patientPhone: string;
  patientEmail: string;
  doctorId: string;
  doctorName: string;
  doctorSpecialization: Specialization;
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g., "10:00 AM"
  fee: number;
  paymentStatus: 'Pending' | 'Paid';
  transactionId: string | null;
  status: 'Upcoming' | 'Completed' | 'Cancelled';
}

export interface SystemStats {
  totalDoctors: number;
  totalPatients: number;
  totalAppointments: number;
  totalRevenue: number;
}
